import RequireAuthWrapper from './components/common/RequireAuthWrapper'
import Dashboard from './pages/member/Dashboard'
import { Provider } from 'react-redux'
import { Route, Routes } from 'react-router-dom'
import store from './store'
import * as S from './App.style'
import Login from './pages/auth/Login'
import { GlobalStyle } from './styles/Global.style'
import Register from './pages/auth/Register/Register'
import Home from './pages/member/Home'
import Payment from './pages/member/Payment'
import Subscription from './pages/member/Subscription'
import ReadingHistories from './pages/member/ReadingHistories'
import PaymentQR from './pages/member/PaymentQR'
import Profile from './pages/member/Profile'
import AdminGifts from './pages/admin/Gifts'
import AdminRewards from './pages/admin/Rewards'
import AdminSubscriptions from './pages/admin/Subscriptions'
import AdminVouchers from './pages/admin/Vouchers'
import AdminDashboard from './pages/admin/Dashboard'
import PostDetail from './pages/member/PostDetail'
import AdminManagePosts from './pages/admin/Posts'
import AddPost from './pages/admin/AddPost'
import AdminInvoices from './pages/admin/Invoices'

const App = () => {
  return (
    <Provider store={store}>
      <S.App>
        <GlobalStyle />
        <Routes>
          <Route
            path='/login'
            element={<Login />}
          />
          <Route
            path='/register'
            element={<Register />}
          />
          <Route
            path='/payment/checkout/:code'
            element={<Payment />}
          />
          <Route
            path='/'
            element={
              <RequireAuthWrapper
                redirectTo='/admin'
                role='member'
              />
            }
          >
            <Route
              path='/'
              element={<Dashboard />}
            >
              <Route
                path='/'
                element={<Home />}
              />
              <Route
                path='/subscriptions'
                element={<Subscription />}
              />
              <Route
                path='/reading-histories'
                element={<ReadingHistories />}
              />
              <Route
                path='/payment/:code'
                element={<PaymentQR />}
              />
              <Route
                path='/:id/:slug'
                element={<PostDetail />}
              />
              <Route
                path='/profile'
                element={<Profile />}
              />
            </Route>
          </Route>

          <Route
            path='/admin'
            element={
              <RequireAuthWrapper
                redirectTo='/'
                role='admin'
              />
            }
          >
            <Route
              path='/admin'
              element={<AdminDashboard />}
            >
              <Route
                path='/admin/'
                element={<AdminManagePosts />}
              />
              <Route
                path='/admin/posts/add'
                element={<AddPost />}
              />
              <Route
                path='/admin/gifts'
                element={<AdminGifts />}
              />
              <Route
                path='/admin/invoices'
                element={<AdminInvoices />}
              />
              <Route
                path='/admin/rewards'
                element={<AdminRewards />}
              />
              <Route
                path='/admin/subscriptions'
                element={<AdminSubscriptions />}
              />
              <Route
                path='/admin/vouchers'
                element={<AdminVouchers />}
              />
            </Route>
          </Route>
          <Route
            path='*'
            element={<p>Not Found</p>}
          />
        </Routes>
      </S.App>
    </Provider>
  )
}

export default App