import Button from '../../../components/common/Button'
import Input from '../../../components/common/Input'
import LoadingOverlay from '../../../components/common/LoadingOverlay'
import Modal from '../../../components/common/Modal'
import Navbar from '../../../components/common/Navbar'
import { formatRp } from '../../../helpers/Number'
import useModal from '../../../hooks/useModal'
import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useGetInvoiceByCodeQuery, useUpdateWaitingInvoiceMutation } from '../../../store/api/invoice'
import * as S from './Payment.style'
import { ReactComponent as IconSuccess } from '../../../assets/img/ic_success.svg'
import { ReactComponent as IconFailed } from '../../../assets/img/ic_failed.svg'

const Payment = () => {
  const { code } = useParams<{ code: any }>()
  const { data: invoice, isLoading, error } = useGetInvoiceByCodeQuery(code)
  const [updateInvoice, { isLoading: updateLoading }] = useUpdateWaitingInvoiceMutation()
  const [payment, setPayment] = useState<string>('')
  const { isOpen, toggle } = useModal()
  const [paymentError, setPaymentError] = useState<string>('')
  const navigate = useNavigate()

  const onSubmit = async () => {
    setPaymentError('')
    if (!payment) return
    const paymentInt = parseInt(payment)
    if (paymentInt !== invoice?.total) {
      setPaymentError('Incorrect amount. Please pay the correct amount')
      toggle()
      return
    }
    try {
      await updateInvoice(code).unwrap()
      toggle()
    } catch (err) {
      setPaymentError('Something went wrong. Please try again later')
      toggle()
    }
  }

  const renderPayment = () => {
    if (isLoading) {
      return <LoadingOverlay />
    }

    if (!invoice || error) {
      return <p>Something went wrong</p>
    }

    return (
      <>
        <S.Title>Payment Confirmation</S.Title>
        <S.PaymentContainer>
          <S.RowContainer>
            <S.Field>Invoice Code</S.Field>
            <S.SemiColon>:</S.SemiColon>
            <S.Value>{invoice.code}</S.Value>
          </S.RowContainer>
          <S.RowContainer>
            <S.Field>Subscription Plan</S.Field>
            <S.SemiColon>:</S.SemiColon>
            <S.Value>{invoice.subscription?.name}</S.Value>
          </S.RowContainer>
          <S.RowContainer>
            <S.Field>Total Price</S.Field>
            <S.SemiColon>:</S.SemiColon>
            <S.Value>{formatRp(invoice.total)}</S.Value>
          </S.RowContainer>
          <S.RowContainer>
            <Input
              placeholder='Input Payment'
              value={payment}
              type='number'
              onChange={(e) => setPayment(e.target.value)}
            />
          </S.RowContainer>
          <Button
            disabled={!payment}
            onClick={onSubmit}
          >
            Pay
          </Button>
        </S.PaymentContainer>
      </>
    )
  }

  return (
    <S.ExternalContainer>
      <>
        <Navbar
          links={[]}
          isEmpty
        />
        <S.Container>{renderPayment()}</S.Container>
        <Modal
          isOpen={isOpen && !updateLoading}
          toggle={() => {
            if (paymentError) {
              toggle()
            } else {
              navigate('/')
            }
          }}
        >
          <S.InnerModalContainer>
            <S.ModalTitle>Payment {paymentError ? 'Failed' : 'Success'}</S.ModalTitle>
            {paymentError ? <IconFailed /> : <IconSuccess />}
            <S.ModalDescription>
              {paymentError === ''
                ? 'Payment successful. Please wait for your subscription to be confirmed'
                : paymentError}
            </S.ModalDescription>
            {!paymentError && (
              <S.RedirectText onClick={() => navigate('/')}>Return to Home</S.RedirectText>
            )}
          </S.InnerModalContainer>
        </Modal>
      </>
    </S.ExternalContainer>
  )
}

export default Payment
