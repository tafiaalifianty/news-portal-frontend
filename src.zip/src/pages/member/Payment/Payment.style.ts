import styled from 'styled-components'
import { DefaultPageContainer, PageExternalContainer } from '../../../styles/Page.style'

export const ExternalContainer = styled(PageExternalContainer)`
  padding: 50px 3%;
`

export const Container = styled(DefaultPageContainer)`
  position: relative;
  z-index: 0;
  background-color: var(--on-primary);
`

export const Title = styled.h1`
  font-family: 'IBM Plex Serif', sans-serif;
  text-align: center;
  margin-bottom: 40px;
`

export const PaymentContainer = styled.div`
  max-width: 600px;
  margin: 0 auto;
  gap: 30px;
  display: flex;
  flex-direction: column;
`

export const RowContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`

export const Field = styled.p`
  flex: 1;
  font-family: 'Nunito Sans';
  font-weight: 500;
  font-size: 1.2rem;
`

export const SemiColon = styled.p``

export const Value = styled.p`
  flex: 1;
  font-family: 'Nunito Sans';
  font-weight: 700;
  font-size: 1.2rem;
  text-align: right;
`

export const InnerModalContainer = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 40px;

  & > *:nth-child(2) {
    width: 150px;
    height: 150px;
  }
`

export const ModalTitle = styled.h1`
  font-family: 'IBM Plex Serif', sans-serif;
  text-align: center;
  margin-bottom: 40px;
  margin: 0;
`

export const ModalDescription = styled.p`
  font-family: 'Nunito Sans';
  font-weight: 500;
  font-size: 1.2rem;
`

export const RedirectText = styled.p`
  text-align: center;
  font-weight: 700;
  color: var(--primary);

  &:hover {
    cursor: pointer;
    color: var(--text);
  }
`
