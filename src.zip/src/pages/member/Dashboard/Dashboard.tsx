import Navbar, { ILink } from '../../../components/common/Navbar'
import { Outlet } from 'react-router-dom'
import * as S from './Dashboard.style'

const links: ILink[] = [
  { path: '/', name: 'Home' },
  { path: '/subscriptions', name: 'Subscriptions' },
  { path: '/reading-histories', name: 'Reading Histories' },
  { path: '/profile', name: 'Profile' },
]

const Dashboard = () => {
  return (
    <S.ExternalContainer>
      <Navbar links={links} />
      <S.Container>
        <Outlet />
      </S.Container>
    </S.ExternalContainer>
  )
}

export default Dashboard
