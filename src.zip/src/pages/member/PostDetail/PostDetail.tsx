import moment from 'moment'
import { useNavigate, useParams } from 'react-router-dom'
import {
  useGetPostByIDQuery,
  useGetRecommendationPostsQuery,
  useLikePostMutation,
  useSharePostMutation,
} from '../../../store/api/post'
import * as S from './PostDetail.style'
import { ReactComponent as UnlikedIcon } from '../../../assets/img/post/ic_unliked.svg'
import { ReactComponent as LikedIcon } from '../../../assets/img/post/ic_liked.svg'
import { ReactComponent as UnsharedIcon } from '../../../assets/img/post/ic_unshared.svg'
import { ReactComponent as SharedIcon } from '../../../assets/img/post/ic_shared.svg'
import PostCard from '../../../components/member/PostCard'
import Shimmer from './Shimmer'
import Response from '../../../types/Response'

const PostDetail = () => {
  const { id } = useParams<{ id: any }>()
  const navigate = useNavigate()
  const {
    data: recommendationPosts,
    isLoading: recommendationLoading,
    error: recommendationError,
  } = useGetRecommendationPostsQuery(undefined, { refetchOnMountOrArgChange: true })

  const {
    data: postDetail,
    isLoading: postDetailLoading,
    error: postDetailError,
  } = useGetPostByIDQuery(id)
  const [likePost, { isLoading: likeLoading }] = useLikePostMutation()
  const [sharePost, { isLoading: shareLoading }] = useSharePostMutation()

  const onLike = async () => {
    if (!postDetail || likeLoading) return
    try {
      await likePost({ isLike: !postDetail.is_liked, id: postDetail.id })
    } catch (err) {
      console.error(err)
    }
  }

  const onShare = async () => {
    if (!postDetail || shareLoading) return
    await navigator.clipboard.writeText(window.location.href)
    if (!postDetail.is_shared) {
      try {
        await sharePost(postDetail.id)
      } catch (err) {
        console.error(err)
      }
    }
    alert('Link copied to clipboard')
  }

  const renderRecommendation = () => {
    if ((!recommendationPosts || recommendationError) && !recommendationLoading) {
      return <p>Something went wrong</p>
    }

    return recommendationPosts && recommendationPosts?.length > 0 ? (
      <S.RecommendedPostsContainer>
        {recommendationPosts?.map((post) => (
          <S.RecommendedPostCard
            key={post.id}
            post={post}
            onClick={() => navigate(`/${post.id}/${post.slug}`)}
            isCompact
          />
        ))}
        {recommendationLoading && <PostCard.Shimmer totalItems={3} />}
      </S.RecommendedPostsContainer>
    ) : (
      ''
    )
  }

  if (postDetailLoading) {
    return <Shimmer />
  }

  if (!postDetail || postDetailError) {
    const errorCasted = postDetailError as Response
    if (errorCasted.data.message === 'not enough quota') {
      return (
        <S.NotEnoughQuotaContainer>
          {' '}
          <S.NotEnoughQuotaText>
            Apparently you don&#39;t have enough quota. Please subscribe to enjoy more of our news!
          </S.NotEnoughQuotaText>
          <S.NotEnoughQuotaButton onClick={() => navigate('/subscriptions')}>
            Subscribe
          </S.NotEnoughQuotaButton>
        </S.NotEnoughQuotaContainer>
      )
    }
    return <p>Something went wrong</p>
  }

  return (
    <S.Container>
      <S.Title>{postDetail.title}</S.Title>
      <S.Subtitle>
        {postDetail.category} | {postDetail.type}
      </S.Subtitle>
      <S.Image src={postDetail.img_url} />
      <S.DetailContainer>
        <S.Time>{moment(postDetail.created_at).format('MMM Do YYYY')}</S.Time>
        <S.Author>By {postDetail.author_name}</S.Author>
        <S.InteractionContainer>
          <S.Interaction onClick={onLike}>
            {postDetail.is_liked ? <LikedIcon /> : <UnlikedIcon />}
            <span>{postDetail.like_count}</span>
          </S.Interaction>
          <S.Interaction onClick={onShare}>
            {postDetail.is_shared ? <SharedIcon /> : <UnsharedIcon />}
            <span>{postDetail.share_count}</span>
          </S.Interaction>
        </S.InteractionContainer>
      </S.DetailContainer>
      <S.Content>
        {postDetail.content.split('\\n').map((paragraph: string) => (
          <S.Paragraph
            data-testid='content-paragraph'
            key={paragraph}
          >
            {paragraph}
          </S.Paragraph>
        ))}
      </S.Content>
      <S.RecommendedContainer>
        <S.RecommendedTitle>Recommended News</S.RecommendedTitle>
        {renderRecommendation()}
      </S.RecommendedContainer>
    </S.Container>
  )
}

export default PostDetail
