import * as S from './Shimmer.style'

const Shimmer = () => {
  return (
    <S.Container>
      <S.Title />
      <S.Subtitle />
      <S.Image />
      <S.Detail />
      <S.Content>
        <S.Paragraph />
        <S.Paragraph />
        <S.Paragraph />
        <S.Paragraph />
      </S.Content>
      <S.Content>
        <S.Paragraph />
        <S.Paragraph />
        <S.Paragraph />
        <S.Paragraph />
      </S.Content>
    </S.Container>
  )
}

export default Shimmer
