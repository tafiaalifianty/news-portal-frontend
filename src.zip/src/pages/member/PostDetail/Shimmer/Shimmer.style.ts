import styled from 'styled-components'
import { BaseShimmer } from '../../../../styles/Shimer.style'

export const Container = styled.div``

export const Title = styled(BaseShimmer)`
  height: 2.4rem;
  margin-bottom: 10px;
`

export const Subtitle = styled(BaseShimmer)`
  height: 1rem;
  width: 20%;
  margin-bottom: 30px;
`

export const Image = styled(BaseShimmer)`
  width: 100%;
  height: auto;
  aspect-ratio: 2 / 1;
  margin-bottom: 20px;
`

export const Detail = styled(BaseShimmer)`
  height: 0.8rem;
  margin-bottom: 20px;
  width: 40%;
`

export const Content = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
  margin-bottom: 40px;
`

export const Paragraph = styled(BaseShimmer)`
  height: 1.1rem;

  &:first-child {
    margin-left: 50px;
  }
`
