import { renderWithProviders } from '../../../helpers/TestHelpers'
import { BrowserRouter } from 'react-router-dom'
import PostDetail from './PostDetail'
import { rest } from 'msw'
import { setupServer } from 'msw/node'
import { screen, waitFor } from '@testing-library/react'

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'), // use actual for all non-hook parts
  useParams: () => ({
    id: '1',
  }),
}))

const mockData = {
  id: 1,
  title: 'title',
  content: 'content 1 \\n content 2 \\n content 3',
  category: 'category',
  type: 'type',
  author_name: 'author_name',
  share_count: 0,
  like_count: 0,
  created_at: '2022-10-21T17:35:09.570822+07:00',
}

describe('PostDetail Page', () => {
  const server = setupServer()
  beforeAll(() => {
    server.listen()
  })
  afterEach(() => {
    server.resetHandlers()
  })
  afterAll(() => server.close())

  describe('onFetch', () => {
    test('should show error on failed fetch', async () => {
      server.use(
        rest.get(`${process.env.REACT_APP_BASE_URL}/posts/1`, async (req, res, ctx) => {
          return await res(ctx.status(500))
        })
      )

      renderWithProviders(
        <BrowserRouter>
          <PostDetail />
        </BrowserRouter>
      )

      await waitFor(() => {
        expect(screen.getByText('Loading...')).toBeInTheDocument()
      })

      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument()
        expect(screen.getByText('Something went wrong')).toBeInTheDocument()
      })
    })

    test('should show post on successful fetch', async () => {
      server.use(
        rest.get(`${process.env.REACT_APP_BASE_URL}/posts/1`, async (req, res, ctx) => {
          return await res(
            ctx.json({
              data: mockData,
            })
          )
        })
      )

      renderWithProviders(
        <BrowserRouter>
          <PostDetail />
        </BrowserRouter>
      )

      await waitFor(() => {
        expect(screen.getByText('Loading...')).toBeInTheDocument()
      })

      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument()
      })

      expect(screen.getAllByTestId('content-paragraph').length).toBe(3)
    })
  })
})
