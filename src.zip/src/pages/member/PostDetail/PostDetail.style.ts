import Button from '../../../components/common/Button'
import PostCard from '../../../components/member/PostCard'
import styled from 'styled-components'

export const Container = styled.div``

export const Title = styled.h1`
  font-family: 'Inria Sans', sans-serif;
  font-size: 500;
  font-size: 2.4rem;
  margin-bottom: 10px;
`

export const Subtitle = styled.p`
  font-size: 1rem;
  font-family: 'Inria Sans', sans-serif;
  margin-bottom: 30px;
`

export const Image = styled.img`
  width: 100%;
  height: auto;
  aspect-ratio: 2 / 1;
  object-fit: cover;
  margin-bottom: 20px;
`

export const DetailContainer = styled.div`
  font-family: 'Questrial', serif;
  font-size: 0.8rem;
  display: flex;
  gap: 10px;
  margin-bottom: 10px;
`

export const Time = styled.p``

export const Author = styled.p`
  color: var(--text-muted);
`

export const InteractionContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`

export const Interaction = styled.div`
  display: flex;
  align-items: center;
  gap: 5px;

  & > *:first-child {
    width: 1rem;
    height: 1rem;
  }

  &:hover {
    cursor: pointer;
  }
`

export const Content = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
`

export const Paragraph = styled.p`
  font-family: 'Open Sans', sans-serif;
  font-size: 1.1rem;
  white-space: pre-line;
`

export const RecommendedContainer = styled.div`
  margin-top: 40px;
`

export const RecommendedTitle = styled.h2`
  font-family: 'Inria Sans', sans-serif;
  font-size: 500;
  font-size: 1.5rem;
  margin-bottom: 10px;
`

export const RecommendedPostsContainer = styled.div`
  display: flex;
  gap: 20px;

  @media (max-width: 480px) {
    flex-direction: column;
  }
`

export const RecommendedPostCard = styled(PostCard)`
  max-width: 400px;
`

export const NotEnoughQuotaContainer = styled.div`
  background-color: var(--on-primary);
  padding: 40px;
  width: 100%;
  border-radius: 12px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
`

export const NotEnoughQuotaText = styled.p`
  font-family: var(--normal-text);
  font-weight: 700;
  font-size: 1.2rem;
`

export const NotEnoughQuotaButton = styled(Button)`
  width: 200px;
`
