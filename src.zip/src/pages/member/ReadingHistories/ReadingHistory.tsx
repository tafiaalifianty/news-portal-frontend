import NoData from '../../../components/common/NoData'
import PostCard from '../../../components/member/PostCard'
import { useNavigate } from 'react-router-dom'
import { useGetUserHistoriesQuery } from '../../../store/api/user'
import * as S from './ReadingHistories.style'

const HistoryTab = () => {
  const { data: histories, isLoading, error } = useGetUserHistoriesQuery()
  const navigate = useNavigate()

  const renderHistories = () => {
    if ((!histories || error) && !isLoading) {
      return <p>Something went wrong</p>
    }

    if (histories && histories.length === 0) {
      return <NoData text="You haven't read any post yet" />
    }

    return (
      <S.PostsContainer>
        {histories?.map((history) => (
          <PostCard
            key={history.post.id}
            post={history.post}
            onClick={() => navigate(`/${history.post.id}/${history.post.slug}`)}
          />
        ))}
        {isLoading && <PostCard.Shimmer totalItems={10} />}
      </S.PostsContainer>
    )
  }

  return (
    <S.Container>
      <S.Title>Your Reading Histories</S.Title>
      {renderHistories()}
    </S.Container>
  )
}

export default HistoryTab
