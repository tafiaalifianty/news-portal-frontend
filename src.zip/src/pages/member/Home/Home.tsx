import NoData from '../../../components/common/NoData'
import FilterBar from '../../../components/member/FilterBar'
import PostCard from '../../../components/member/PostCard'
import React, { useEffect, useState } from 'react'
import { InView } from 'react-intersection-observer'
import { useNavigate } from 'react-router-dom'
import { useGetAllPostQuery, useGetTrendingPostsQuery } from '../../../store/api/post'
import Post from '../../../types/Post'
import * as S from '../../member/Home/Home.style'

const Home = () => {
  const navigate = useNavigate()
  const [page, setPage] = useState<number>(1)
  const [reset, setReset] = useState<boolean>(false)
  const [posts, setPosts] = useState<Post[]>([])
  const [filters, setFilters] = useState({
    search: '',
    sort: 'desc',
    category: '0',
    type: '0',
  })
  const { data, isFetching, error } = useGetAllPostQuery(
    {
      page,
      search: filters.search,
      sort: filters.sort,
      category: filters.category,
      type: filters.type,
    },
    { skip: reset }
  )
  const {
    data: trendingPosts,
    isLoading: trendingLoading,
    error: trendingError,
  } = useGetTrendingPostsQuery()

  useEffect(() => {
    if (data) {
      setPosts([...posts, ...data.data])
    }
  }, [data])

  useEffect(() => {
    if (reset) {
      setPage(1)
      setPosts([])
    }
  }, [reset])

  useEffect(() => {
    setReset(false)
  }, [filters])

  const onFilterChange = (name: 'search' | 'sort' | 'category' | 'type', value: string) => {
    setReset(true)
    setFilters({
      ...filters,
      [name]: value,
    })
  }

  const onInViewChange = (inView: boolean) => {
    if (inView && data && page < data.total_pages) {
      setPage(page + 1)
    }
  }

  const renderPostInView = (children: React.ReactNode) => {
    return data && page < data.total_pages && !reset ? (
      <InView onChange={onInViewChange}>{children}</InView>
    ) : (
      <React.Fragment>{children}</React.Fragment>
    )
  }

  const renderPostLists = () => {
    if ((!data || error) && !isFetching) {
      return <p>Something went wrong</p>
    }

    if (!isFetching && posts.length === 0) {
      return (
        <S.NoDataContainer>
          <NoData text='No Post Data Found' />
        </S.NoDataContainer>
      )
    }

    return (
      <>
        {posts.map((post, idx) =>
          idx !== posts.length - 1 ? (
            <PostCard
              key={post.id}
              post={post}
              onClick={() => navigate(`/${post.id}/${post.slug}`)}
            />
          ) : (
            <React.Fragment key={post.id}>
              {renderPostInView(
                <PostCard
                  key={post.id}
                  post={post}
                  onClick={() => navigate(`/${post.id}/${post.slug}`)}
                />
              )}
            </React.Fragment>
          )
        )}
        {isFetching && <PostCard.Shimmer totalItems={10} />}
      </>
    )
  }

  const renderTrendingPosts = () => {
    if ((!trendingPosts || trendingError) && !trendingLoading) {
      return <p>Something went wrong</p>
    }

    if (trendingPosts && trendingPosts.length === 0) {
      return (
        <S.NoDataContainer>
          <NoData text='No Trending Post Found' />
        </S.NoDataContainer>
      )
    }

    return (
      <S.TrendingPostsListContainer>
        {trendingPosts?.map((post) => (
          <S.TrendingPostCard
            isCompact
            key={post.id}
            post={post}
            onClick={() => navigate(`/${post.id}/${post.slug}`)}
          />
        ))}
        {trendingLoading && <PostCard.Shimmer totalItems={4} />}
      </S.TrendingPostsListContainer>
    )
  }

  return (
    <>
      <S.TrendingContainer>
        <S.Title>Trending News</S.Title>
        {renderTrendingPosts()}
      </S.TrendingContainer>
      <S.MainContainer>
        <S.Title>Recent News</S.Title>
        <FilterBar
          onSearch={(val) => onFilterChange('search', val)}
          onDateSort={(val) => onFilterChange('sort', val)}
          onCategoryFilter={(val) => onFilterChange('category', val)}
          onTypeFilter={(val) => onFilterChange('type', val)}
        />
        <S.PostsListContainer>{renderPostLists()}</S.PostsListContainer>
      </S.MainContainer>
    </>
  )
}

export default Home
