import PostCard from '../../../components/member/PostCard'
import styled from 'styled-components'

export const TrendingContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
  margin-bottom: 40px;
`

export const Title = styled.h1``

export const TrendingPostsListContainer = styled.div`
  display: flex;
  gap: 16px;
  overflow-x: auto;
  overflow-y: hidden;
  padding-bottom: 20px;

  & > * {
    min-width: 300px;
  }
`

export const TrendingPostCard = styled(PostCard)`
  width: 300px;
`

export const MainContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
`

export const PostsListContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;

  @media (max-width: 1024px) {
    grid-template-columns: repeat(2, 1fr);
  }

  @media (max-width: 480px) {
    grid-template-columns: repeat(1, 1fr);
  }
`

export const SpinnerContainer = styled.div`
  display: flex;
  justify-content: center;
`

export const NoDataContainer = styled.div`
  margin: auto;
`
