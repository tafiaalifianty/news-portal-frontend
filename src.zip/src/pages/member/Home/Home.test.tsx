import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithProviders } from '../../../helpers/TestHelpers'
import { createMemoryHistory } from 'history'
import { rest } from 'msw'
import { setupServer } from 'msw/node'
import { BrowserRouter, Router } from 'react-router-dom'
import Home from './Home'

describe('Home Page', () => {
  const server = setupServer()
  beforeAll(() => {
    server.listen()
  })
  afterEach(() => {
    server.resetHandlers()
  })
  afterAll(() => server.close())

  describe('on Data Fetch', () => {
    test('should show error on failed fetch', async () => {
      server.use(
        rest.get(`${process.env.REACT_APP_BASE_URL}/posts`, async (req, res, ctx) => {
          return await res(ctx.status(500))
        })
      )

      renderWithProviders(
        <BrowserRouter>
          <Home />
        </BrowserRouter>
      )

      await waitFor(() => {
        expect(screen.getByText('Loading...')).toBeInTheDocument()
      })

      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument()
        expect(screen.getByText('Something went wrong')).toBeInTheDocument()
      })
    })
    test('should show posts on Successful fetch', async () => {
      server.use(
        rest.get(`${process.env.REACT_APP_BASE_URL}/posts`, async (req, res, ctx) => {
          return await res(
            ctx.json({
              data: {
                data: [
                  {
                    id: 31,
                  },
                  {
                    id: 32,
                  },
                ],
              },
            })
          )
        })
      )

      renderWithProviders(
        <BrowserRouter>
          <Home />
        </BrowserRouter>
      )

      await waitFor(() => {
        expect(screen.getByText('Loading...')).toBeInTheDocument()
      })

      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument()
        expect(screen.getAllByTestId('post-card').length).toBe(2)
      })
    })
  })

  test('should navigate to appropriate id/slug links', async () => {
    server.use(
      rest.get(`${process.env.REACT_APP_BASE_URL}/posts`, async (req, res, ctx) => {
        return await res(
          ctx.json({
            data: {
              data: [
                {
                  id: 1,
                  slug: 'slug',
                },
              ],
            },
          })
        )
      })
    )

    const history = createMemoryHistory()
    history.push('/random-route')
    renderWithProviders(
      <Router
        location={history.location}
        navigator={history}
      >
        <Home />
      </Router>
    )

    await waitFor(() => {
      expect(screen.getByText('Loading...')).toBeInTheDocument()
    })

    await waitFor(() => {
      expect(screen.queryByText('Loading...')).not.toBeInTheDocument()
    })

    userEvent.click(screen.getByTestId('post-card'))

    await waitFor(() => {
      expect(history.location.pathname).toBe('/1/slug')
    })
  })
})
