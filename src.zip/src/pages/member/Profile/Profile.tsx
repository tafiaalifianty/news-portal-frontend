import Spinner from '../../../components/common/Spinner'
import Tabs from '../../../components/common/Tabs'
import ReferralTabs from '../../../components/member/ReferralTabs'
import RewardsTab from '../../../components/member/RewardsTab'
import VouchersTab from '../../../components/member/VouchersTab'
import { useGetProfileQuery } from '../../../store/api/auth'
import * as S from './Profile.style'
import { ReactComponent as EditIcon } from '../../../assets/img/ic_edit.svg'
import useModal from '../../../hooks/useModal'
import Modal from '../../../components/common/Modal'
import React, { useEffect, useState } from 'react'
import Button from '../../../components/common/Button'
import { useGetUserSubscriptionsQuery, useUpdateUserProfileMutation } from '../../../store/api/user'
import LoadingOverlay from '../../../components/common/LoadingOverlay'
import SubscriptionsTab from '../../../components/member/SubscriptionsTab'

const profileTabs = [
  { name: 'Rewards', content: <RewardsTab /> },
  { name: 'Referrals', content: <ReferralTabs /> },
  { name: 'Vouchers', content: <VouchersTab /> },
  { name: 'Subscriptions', content: <SubscriptionsTab /> },
]

const Profile = () => {
  const { data: profile, isLoading: profileLoading, error: profileError } = useGetProfileQuery()
  const { toggle, isOpen } = useModal()
  const [editValues, setEditValues] = useState({
    fullname: '',
    address: '',
  })
  const [updateProfile, { isLoading: updateLoading }] = useUpdateUserProfileMutation()
  const {
    data: subscriptions,
    isLoading: subscriptionsLoading,
    error: subscriptionsError,
  } = useGetUserSubscriptionsQuery(undefined, {
    refetchOnMountOrArgChange: true,
  })

  useEffect(() => {
    if (profile) {
      setEditValues({
        fullname: profile.fullname,
        address: profile.address,
      })
    }
  }, [profile])

  const handleEditValuesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEditValues({
      ...editValues,
      [e.target.name]: e.target.value,
    })
  }

  const handleEditSubmit = async () => {
    try {
      await updateProfile(editValues).unwrap()
    } catch (err) {
      console.error(err)
    } finally {
      toggle()
    }
  }

  const renderSubscriptionsQuota = () => {
    if (subscriptionsLoading) {
      return <Spinner size={20} />
    }

    if (!subscriptions || subscriptionsError) {
      return <p>Cannot load quota</p>
    }

    return (
      <S.ReferralCode>
        {subscriptions.reduce(function (acc, obj) {
          return acc + obj.remaining_quota
        }, 0)}
      </S.ReferralCode>
    )
  }

  return (
    <S.Container>
      {updateLoading && <LoadingOverlay />}
      <S.ProfileContainer>
        {profileLoading && <Spinner />}
        {profileError ? (
          <S.ErrorText>Cannot display profile</S.ErrorText>
        ) : (
          <>
            <S.NameContainer>
              <S.NameText>{profile?.fullname}</S.NameText>
              <EditIcon onClick={toggle} />
            </S.NameContainer>
            <S.EmailText>{profile?.email}</S.EmailText>
            <S.AddressText>{profile?.address}</S.AddressText>
            {profile?.referral_code && (
              <S.ReferralContainer>
                <p>Code:</p>
                <S.ReferralCode>{profile.referral_code}</S.ReferralCode>
              </S.ReferralContainer>
            )}
            <S.ReferralContainer>
              <p>Quota:</p>
              {renderSubscriptionsQuota()}
            </S.ReferralContainer>
          </>
        )}
      </S.ProfileContainer>
      <S.TabsContainer>
        <Tabs tabs={profileTabs} />
      </S.TabsContainer>
      <Modal
        isOpen={isOpen}
        toggle={toggle}
      >
        <S.ModalTitle>Edit Profile</S.ModalTitle>
        <S.ModalBody>
          <S.ModalRow>
            <S.ModalLabel>Full name</S.ModalLabel>
            <S.ModalInput
              value={editValues.fullname}
              name='fullname'
              onChange={(e) => handleEditValuesChange(e)}
            />
          </S.ModalRow>
          <S.ModalRow>
            <S.ModalLabel>Address</S.ModalLabel>
            <S.ModalInput
              value={editValues.address}
              name='address'
              onChange={(e) => handleEditValuesChange(e)}
            />
          </S.ModalRow>
          <Button
            onClick={async () => {
              await handleEditSubmit()
            }}
          >
            Submit
          </Button>
          <S.ModalCancel onClick={toggle}>Cancel</S.ModalCancel>
        </S.ModalBody>
      </Modal>
    </S.Container>
  )
}

export default Profile
