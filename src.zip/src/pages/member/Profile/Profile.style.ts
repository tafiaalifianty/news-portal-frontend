import Input from '../../../components/common/Input'
import styled from 'styled-components'

export const Container = styled.div`
  display: flex;
  gap: 30px;
  @media (max-width: 768px) {
    flex-direction: column;
  }
`

export const ProfileContainer = styled.div`
  background-color: var(--on-primary);
  padding: 40px;
  border-radius: 12px;
  flex: 1;
`

export const ErrorText = styled.p``

export const NameContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;

  & > *:nth-child(2) {
    fill: #393E46;
    border-bottom: 2px solid transparent;
    transition: 250ms ease-out;

    &:hover {
      opacity: 0.7;
      border-bottom: 2px solid #393E46;
      cursor: pointer;
    }
  }
`

export const NameText = styled.p`
  font-family: var(--normal-text);
  font-size: 2rem;
  font-weight: 700;
`

export const EmailText = styled.p`
  font-family: var(--normal-text);
  font-size: 1rem;
  font-weight: 400;
`

export const AddressText = styled.p`
  margin-top: 10px;
  font-size: 0.8rem;
`

export const ReferralContainer = styled.div`
  margin-top: 20px;
  font-family: var(--normal-text);
`

export const ReferralCode = styled.p`
  font-size: 1.25rem;
  font-weight: 700;
  margin-top: 5px;
`

export const TabsContainer = styled.div`
  background-color: var(--on-primary);
  padding: 40px;
  border-radius: 12px;
  flex: 3;
`

export const ModalTitle = styled.h2`
  font-family: var(--normal-text);
  font-size: 2rem;
  font-weight: 700;
  text-align: center;
  margin-bottom: 20px;
`

export const ModalBody = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
`

export const ModalRow = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`

export const ModalLabel = styled.label`
  flex: 1;
`

export const ModalInput = styled(Input)`
  flex: 2;
  background-color: transparent;
  border-bottom: 1px solid var(--border);
  border-radius: 0;
`

export const ModalCancel = styled.p`
  text-align: center;
  font-weight: 700;
  color: var(--primary);

  &:hover {
    cursor: pointer;
    color: var(--text);
  }
`
