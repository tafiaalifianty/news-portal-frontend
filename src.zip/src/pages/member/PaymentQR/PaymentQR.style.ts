import styled from 'styled-components'

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 30px;
  padding: 40px;
  background-color: var(--on-primary);
`

export const Title = styled.h1`
  font-family: 'IBM Plex Serif', sans-serif;
  font-weight: 700;
  margin-bottom: 10px;
`

export const Subtitle = styled.p`
  font-family: var(--normal-text);
  color: var(--text-muted);
  text-align: center;
`

export const Description = styled.p`
  font-family: 'Nunito Sans', sans-serif;
  font-size: 1.2rem;
`
