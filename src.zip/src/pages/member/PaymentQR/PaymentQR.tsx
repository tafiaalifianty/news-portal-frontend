import * as S from './PaymentQR.style'
import QRCode from 'react-qr-code'
import { useParams } from 'react-router-dom'
import Response from '../../../types/Response'
import { useGetInvoiceByCodeProtectedQuery } from '../../../store/api/invoice'
import Spinner from '../../../components/common/Spinner'

const PaymentQR = () => {
  const { code } = useParams<{ code: any }>()
  const { data: invoice, isLoading, error } = useGetInvoiceByCodeProtectedQuery(code)

  if (isLoading) {
    return <Spinner />
  }

  if (!invoice || error) {
    const errorCasted = error as Response
    if (errorCasted.data.code === 401) {
      return <p>No access to this payment</p>
    }

    if (errorCasted.data.message === 'invoice not awaiting payment') {
      return <p>Invoice not awaiting payment</p>
    }
    return <p>Something went wrong</p>
  }

  return (
    <S.Container>
      <div>
        <S.Title>Payment QR Code</S.Title>
        <S.Subtitle>Invoice Code: {invoice.code}</S.Subtitle>
      </div>
      <QRCode
        level='L'
        value={`${window.location.origin.toString()}/payment/checkout/${code}`}
      />
      <S.Description>Scan the QR Code to complete your payment</S.Description>
    </S.Container>
  )
}

export default PaymentQR
