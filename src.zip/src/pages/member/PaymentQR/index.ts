export { default } from './PaymentQR'
