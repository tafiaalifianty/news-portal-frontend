import styled from 'styled-components'

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  gap: 40px;
`

export const Title = styled.h1`
  font-family: 'IBM Plex Serif', sans-serif;
  text-align: center;
  margin-bottom: 40px;
`

export const CardContainers = styled.div`
  display: flex;
  gap: 16px;
  align-items: center;

  @media (max-width: 768px) {
    flex-direction: column;
  }
`

export const InvoicesHistoriesContainer = styled.div`
  background-color: var(--on-primary);
  padding: 20px;
  border-radius: 5px;
`

export const InvoicesHistoriesTitle = styled.h2`
  font-family: 'Nunito Sans', sans-serif;
  font-weight: 600;
  margin-bottom: 20px;
`

export const ModalTitle = styled.h1`
  font-family: 'IBM Plex Serif', sans-serif;
  text-align: center;
  margin-bottom: 40px;
`

export const ModalContainer = styled.div``

export const PaymentContainer = styled.div`
  max-width: 600px;
  margin: 0 auto;
  gap: 30px;
  display: flex;
  flex-direction: column;
`

export const RowContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`

export const Optional = styled.span`
  display: block;
  font-size: 0.8rem;
  color: var(--text-muted);
`

export const Field = styled.p`
  flex: 1;
  font-family: 'Nunito Sans';
  font-weight: 500;
  font-size: 1.2rem;
`

export const SemiColon = styled.p``

export const Value = styled.p`
  flex: 1;
  font-family: 'Nunito Sans';
  font-weight: 700;
  font-size: 1.2rem;
  padding-left: 10px;
`

export const VoucherInput = styled.input`
  outline: none;
  border: none;
  border-bottom: 1px solid var(--border);
  padding: 5px 10px;
  padding-right: 0;
  font-family: 'Nunito Sans';
`

export const ActionContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 15px;
`

export const Cancel = styled.p`
  text-align: center;
  font-weight: 700;
  color: var(--primary);

  &:hover {
    cursor: pointer;
    color: var(--text);
  }
`
