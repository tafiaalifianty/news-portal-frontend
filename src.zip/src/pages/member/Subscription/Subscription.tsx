import Button from '../../../components/common/Button'
import LoadingOverlay from '../../../components/common/LoadingOverlay'
import Modal from '../../../components/common/Modal'
import Spinner from '../../../components/common/Spinner'
import InvoiceTab from '../../../components/member/InvoiceTab'
import SubscriptionCard from '../../../components/member/SubscriptionCard'
import { formatRp } from '../../../helpers/Number'
import useModal from '../../../hooks/useModal'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { BuySubscriptionRequestBody, useBuySubscriptionMutation } from '../../../store/api/invoice'
import { useGetSubscriptionsQuery } from '../../../store/api/subscription'
import Invoice from '../../../types/Invoice'
import Response from '../../../types/Response'
import Subscription from '../../../types/Subscription'
import * as S from './Subscription.style'

const SubscriptionPage = () => {
  const { data: subscriptions, isLoading, error } = useGetSubscriptionsQuery()
  const { isOpen, toggle } = useModal()
  const [buySubscription, { isLoading: buyLoading, error: buyError }] = useBuySubscriptionMutation()
  const navigate = useNavigate()
  const [activeSubscription, setActiveSubscription] = useState<Subscription | undefined>(undefined)
  const [voucherCode, setVoucherCode] = useState<string>('')

  const renderCards = () => {
    return subscriptions?.map((subscription) => (
      <SubscriptionCard
        subscription={subscription}
        key={subscription.id}
        onClick={() => onSubscriptionClick(subscription)}
      />
    ))
  }

  const onConfirm = async () => {
    if (!activeSubscription) return
    const payload: BuySubscriptionRequestBody = {
      original_price: activeSubscription.price,
      subscription_id: activeSubscription.id,
      voucher_code: voucherCode,
    }
    try {
      const response = await buySubscription(payload).unwrap()
      const invoice: Invoice = response.data as Invoice
      navigate(`/payment/${invoice.code}`)
    } catch (err) {
      console.error(err)
    }
  }

  const onSubscriptionClick = (subscription: Subscription) => {
    setActiveSubscription(subscription)
    toggle()
  }

  if (isLoading) {
    return <Spinner />
  }

  if (!subscriptions || error) {
    return <p>Something went wrong</p>
  }

  return (
    <>
      <S.Container>
        <S.Title>Subscription Plans</S.Title>
        <S.CardContainers>{renderCards()}</S.CardContainers>
        <S.InvoicesHistoriesContainer>
          <S.InvoicesHistoriesTitle>Purchased Subscription Histories</S.InvoicesHistoriesTitle>
          <InvoiceTab />
        </S.InvoicesHistoriesContainer>
      </S.Container>
      {activeSubscription && (
        <Modal
          isOpen={isOpen}
          toggle={toggle}
        >
          {buyLoading && <LoadingOverlay />}
          <S.ModalContainer>
            <S.Title>Payment Confirmation</S.Title>
            <S.PaymentContainer>
              <S.RowContainer>
                <S.Field>Subscription Plan</S.Field>

                <S.Value>{activeSubscription.name}</S.Value>
              </S.RowContainer>
              <S.RowContainer>
                <S.Field>Valid For</S.Field>

                <S.Value>1 Month</S.Value>
              </S.RowContainer>
              <S.RowContainer>
                <S.Field>Price</S.Field>

                <S.Value>{formatRp(activeSubscription.price)}</S.Value>
              </S.RowContainer>
              <S.RowContainer>
                <S.Field>
                  Voucher Code<S.Optional>Optional</S.Optional>
                </S.Field>

                <S.VoucherInput
                  value={voucherCode}
                  onChange={(e) => setVoucherCode(e.target.value)}
                  placeholder='Voucher Code Ex: AYUS52'
                />
              </S.RowContainer>
              <S.ActionContainer>
                <Button onClick={onConfirm}>Confirm Payment</Button>
                <S.Cancel onClick={toggle}>Cancel</S.Cancel>
                {error && <span>{(buyError as Response).data.message}</span>}
              </S.ActionContainer>
            </S.PaymentContainer>
          </S.ModalContainer>
        </Modal>
      )}
    </>
  )
}

export default SubscriptionPage
