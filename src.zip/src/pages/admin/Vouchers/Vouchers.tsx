import Table, { TableHeader } from '../../../components/admin/Table/Table'
import Spinner from '../../../components/common/Spinner'
import { useGetAllVouchersQuery } from '../../../store/api/voucher'
import * as S from './Vouchers.style'

const voucherHeaders: TableHeader[] = [
  { value: 'ID', name: 'id' },
  { value: 'Name', name: 'name' },
  { value: 'Discount', name: 'discount' },
  { value: 'Minimum Spending', name: 'minimum_spending' },
]

const Subscriptions = () => {
  const { data, isLoading, error } = useGetAllVouchersQuery()

  const renderSubscriptionsTable = () => {
    if (isLoading) {
      return <Spinner />
    }

    if (!data || error) {
      return <p>Something went wrong</p>
    }

    return (
      <Table
        data={data}
        headers={voucherHeaders}
      />
    )
  }

  return (
    <S.Container>
      <S.HeaderContainer>
        <S.Title>Manage Vouchers</S.Title>
      </S.HeaderContainer>
      {renderSubscriptionsTable()}
    </S.Container>
  )
}

export default Subscriptions
