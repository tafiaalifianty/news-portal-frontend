import Table from '../../../components/admin/Table'
import LoadingOverlay from '../../../components/common/LoadingOverlay'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDeletePostMutation, useGetAllPostQuery } from '../../../store/api/post'
import * as S from './Posts.style'
import { ReactComponent as LeftChevronIcon } from '../../../assets/img/ic_chevron_left.svg'
import { ReactComponent as RightChevronIcon } from '../../../assets/img/ic_chevron_right.svg'
import { TableHeader } from '../../../components/admin/Table/Table'
import { ReactComponent as DeleteIcon } from '../../../assets/img/ic_delete.svg'
import Spinner from '../../../components/common/Spinner'

const postsHeaders: TableHeader[] = [
  { value: 'ID', name: 'id' },
  { value: 'Title', name: 'title' },
  { value: 'Category', name: 'category' },
  { value: 'Type', name: 'type' },
  { value: 'Likes', name: 'like_count' },
  { value: 'Share', name: 'share_count' },
  { value: 'Author', name: 'author_name' },
  { value: 'Actions', name: 'action' },
]

const Posts = () => {
  const [page, setPage] = useState<number>(1)
  const { data, isLoading, error } = useGetAllPostQuery({ page })
  const [deletePost, { isLoading: deleteLoading }] = useDeletePostMutation()
  const navigate = useNavigate()

  const onDeleteRow = async (id: number) => {
    try {
      await deletePost(id).unwrap()
    } catch (error) {
      console.error(error)
    }
  }

  const renderPostLists = () => {
    if (isLoading) {
      return <Spinner />
    }

    if (!data || error) {
      return <p>Something went wrong</p>
    }

    return (
      <Table
        data={data.data.map((datum) => ({
          ...datum,
          action: (
            <S.TableColumnAction>
              <S.DeleteButton
                onClick={async () => {
                  await onDeleteRow(datum.id)
                }}
              >
                <DeleteIcon />
              </S.DeleteButton>
            </S.TableColumnAction>
          ),
        }))}
        headers={postsHeaders}
      />
    )
  }

  const onPrevPageClick = () => {
    setPage((prev: number) => prev - 1)
  }

  const onNextPageClick = () => {
    setPage((prev: number) => prev + 1)
  }

  const onAddPostClick = () => {
    navigate('posts/add')
  }

  return (
    <S.Container>
      <S.HeaderContainer>
        <S.Title>Posts</S.Title>
        <S.FilterContainer>
          <S.PaginationContainer>
            <S.PaginationButton
              onClick={onPrevPageClick}
              disabled={page === 1}
            >
              <LeftChevronIcon />
            </S.PaginationButton>
            <S.PageNumber>{page}</S.PageNumber>
            <S.PaginationButton
              onClick={onNextPageClick}
              disabled={page === data?.total_pages}
            >
              <RightChevronIcon />
            </S.PaginationButton>
          </S.PaginationContainer>
          <S.FilterButton onClick={onAddPostClick}>Add Post</S.FilterButton>
        </S.FilterContainer>
      </S.HeaderContainer>
      {renderPostLists()}
      {deleteLoading && <LoadingOverlay />}
    </S.Container>
  )
}

export default Posts
