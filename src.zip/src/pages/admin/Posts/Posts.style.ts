import Button from '../../../components/common/Button'
import styled from 'styled-components'

export const Container = styled.div`
  background-color: white;
  padding: 10px;
  overflow-x: auto;
`

export const HeaderContainer = styled.div`
  padding: 30px;
  display: flex;
  align-items: center;
  justify-content: space-between;
`

export const Title = styled.p`
  font-family: 'Roboto', sans-serif;
  font-size: 1.25rem;
`

export const FilterContainer = styled.div`
  display: flex;
  gap: 5px;
  align-items: center;
`

export const FilterButton = styled(Button)`
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 10px 14px;
  border-radius: 4px;
`

export const PaginationContainer = styled.div`
  display: flex;
  gap: 5px;
  align-items: center;
`

export const PageNumber = styled.span`
  display: block;
  margin: 0 10px;
  font-family: 'Roboto', sans-serif;
`

export const PaginationButton = styled(Button)`
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  fill: var(--primary);
  color: var(--primary);
  border: 1px solid var(--primary);
  background-color: var(--on-primary);

  &:hover {
    fill: var(--on-primary);
    color: var(--on-primary);
    background-color: var(--primary);
  }
`

export const ActionButton = styled(Button)`
  width: 40px;
  height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 10px;
`

export const DeleteButton = styled(ActionButton)``

export const UpdateButton = styled(ActionButton)`
  background-color: #109be9;
  &:hover {
    fill: #109be9;
    border: 1px solid #109be9;
  }
`

export const TableColumnAction = styled.div`
  display: inline-flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: space-between;
  align-items: center;
  height: 100%;
`
