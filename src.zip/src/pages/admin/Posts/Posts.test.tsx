import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithProviders } from '../../../helpers/TestHelpers'
import { createMemoryHistory } from 'history'
import { rest } from 'msw'
import { setupServer } from 'msw/node'
import { BrowserRouter, Router } from 'react-router-dom'
import Posts from './Posts'

describe('Posts Page', () => {
  const server = setupServer()
  beforeAll(() => {
    server.listen()
  })
  afterEach(() => {
    server.resetHandlers()
  })
  afterAll(() => server.close())

  describe('on Data Fetch', () => {
    test('should show error on failed fetch', async () => {
      server.use(
        rest.get(`${process.env.REACT_APP_BASE_URL}/posts`, async (req, res, ctx) => {
          return await res(ctx.status(500))
        })
      )

      renderWithProviders(
        <BrowserRouter>
          <Posts />
        </BrowserRouter>
      )

      await waitFor(() => {
        expect(screen.getByText('Loading...')).toBeInTheDocument()
      })

      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument()
        expect(screen.getByText('Something went wrong')).toBeInTheDocument()
      })
    })
    test('should show table on Successful fetch', async () => {
      server.use(
        rest.get(`${process.env.REACT_APP_BASE_URL}/posts`, async (req, res, ctx) => {
          return await res(
            ctx.json({
              data: {
                data: [],
              },
            })
          )
        })
      )

      renderWithProviders(
        <BrowserRouter>
          <Posts />
        </BrowserRouter>
      )

      await waitFor(() => {
        expect(screen.getByText('Loading...')).toBeInTheDocument()
      })

      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument()
        expect(screen.getByRole('table')).toBeInTheDocument()
      })
    })
  })

  describe('on Delete', () => {})

  describe('Pagination', () => {
    beforeEach(() => {
      server.use(
        rest.get(`${process.env.REACT_APP_BASE_URL}/posts`, async (req, res, ctx) => {
          const page = req.url.searchParams.get('page')
          return await res(
            ctx.json({
              data: {
                data: [],
                per_page: page,
                total_pages: 2,
              },
            })
          )
        })
      )
    })
    test('should disable left pagination button on first page', async () => {
      renderWithProviders(
        <BrowserRouter>
          <Posts />
        </BrowserRouter>
      )

      await waitFor(() => {
        expect(screen.getByText('Loading...')).toBeInTheDocument()
      })

      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument()
        expect(screen.getByRole('table')).toBeInTheDocument()
      })

      expect(screen.getByRole('button', { name: 'ic_chevron_left.svg' })).toBeDisabled()
      expect(screen.getByRole('button', { name: 'ic_chevron_right.svg' })).not.toBeDisabled()
    })

    test('should disable right pagination button on last page', async () => {
      renderWithProviders(
        <BrowserRouter>
          <Posts />
        </BrowserRouter>
      )

      await waitFor(() => {
        expect(screen.getByText('Loading...')).toBeInTheDocument()
      })

      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument()
        expect(screen.getByRole('table')).toBeInTheDocument()
      })

      userEvent.click(screen.getByRole('button', { name: 'ic_chevron_right.svg' }))

      await waitFor(() => {
        expect(screen.getByRole('button', { name: 'ic_chevron_right.svg' })).toBeDisabled()
        expect(screen.getByRole('button', { name: 'ic_chevron_left.svg' })).not.toBeDisabled()
      })
    })

    test('onPrevPageClick should reduce current page by 1', async () => {
      renderWithProviders(
        <BrowserRouter>
          <Posts />
        </BrowserRouter>
      )

      await waitFor(() => {
        expect(screen.getByText('Loading...')).toBeInTheDocument()
      })

      await waitFor(() => {
        expect(screen.queryByText('Loading...')).not.toBeInTheDocument()
        expect(screen.getByRole('table')).toBeInTheDocument()
      })

      userEvent.click(screen.getByRole('button', { name: 'ic_chevron_right.svg' }))
      userEvent.click(screen.getByRole('button', { name: 'ic_chevron_left.svg' }))

      await waitFor(() => {
        expect(screen.getByRole('button', { name: 'ic_chevron_right.svg' })).not.toBeDisabled()
        expect(screen.getByRole('button', { name: 'ic_chevron_left.svg' })).toBeDisabled()
      })
    })
  })

  test('should navigate to add post on add post button click', async () => {
    const history = createMemoryHistory()
    history.push('/random-route')
    renderWithProviders(
      <Router
        location={history.location}
        navigator={history}
      >
        <Posts />
      </Router>
    )

    userEvent.click(screen.getByRole('button', { name: 'Add Post' }))

    await waitFor(() => {
      expect(history.location.pathname).toBe('/posts/add')
    })
  })
})
