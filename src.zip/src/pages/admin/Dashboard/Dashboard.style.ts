import styled from 'styled-components'
import { DefaultPageContainer, PageExternalContainer } from '../../../styles/Page.style'

export const ExternalContainer = styled(PageExternalContainer)``

export const Container = styled(DefaultPageContainer)``
