import Navbar, { ILink } from '../../../components/common/Navbar'
import { Outlet } from 'react-router-dom'
import * as S from './Dashboard.style'

const links: ILink[] = [
  { path: '/admin', name: 'Post' },
  { path: '/admin/subscriptions', name: 'Subscriptions' },
  { path: '/admin/invoices', name: 'Invoices' },
  { path: '/admin/gifts', name: 'Gifts' },
  { path: '/admin/rewards', name: 'Rewards' },
  { path: '/admin/vouchers', name: 'Vouchers' },
]

const Dashboard = () => {
  return (
    <S.ExternalContainer>
      <Navbar links={links} />
      <S.Container>
        <Outlet />
      </S.Container>
    </S.ExternalContainer>
  )
}

export default Dashboard
