import Table from '../../../components/admin/Table'
import { TableHeader } from '../../../components/admin/Table/Table'
import LoadingOverlay from '../../../components/common/LoadingOverlay'
import Spinner from '../../../components/common/Spinner'
import StatusModal from '../../../components/common/StatusModal'
import useModal from '../../../hooks/useModal'
import React, { useState } from 'react'
import { useGetAllGiftsQuery, useUpdateGiftStockMutation } from '../../../store/api/gift'
import * as S from './Gifts.style'

const giftHeaders: TableHeader[] = [
  { value: 'ID', name: 'id' },
  { value: 'Name', name: 'name' },
  { value: 'Stock', name: 'stock' },
  { value: 'Last Updated', name: 'updated_at' },
]

const Gifts = () => {
  const { data, isLoading, error } = useGetAllGiftsQuery()
  const [updateGiftStock, { isLoading: updateLoading }] = useUpdateGiftStockMutation()
  const [edittedID, setEdittedID] = useState<number>(-1)
  const [edittedValue, setEdittedValue] = useState<number>(0)
  const { isOpen, toggle } = useModal()
  const [updateError, setUpdateError] = useState<string>('')

  const handleStockClick = (id: number, value: number) => {
    setEdittedID(id)
    setEdittedValue(value)
  }

  const handleStockInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEdittedValue(parseInt(e.target.value))
  }

  const handleStockInputKeyPress = async (e: React.KeyboardEvent<HTMLInputElement>) => {
    setUpdateError('')
    if (e.key === 'Enter') {
      try {
        await updateGiftStock({
          id: edittedID,
          stock: edittedValue,
        }).unwrap()
      } catch (err) {
        setUpdateError('Something went wrong. Please try again later')
      } finally {
        setEdittedID(-1)
        setEdittedValue(0)
        toggle()
      }
    }
  }

  const renderGiftsTable = () => {
    if (isLoading) {
      return <Spinner />
    }

    if (!data || error) {
      return <p>Something went wrong</p>
    }

    return (
      <Table
        data={data.map((datum) => ({
          ...datum,
          stock:
            edittedID === datum.id ? (
              <S.InputStock
                type='number'
                value={edittedValue}
                onChange={handleStockInputChange}
                onKeyPress={async (e) => {
                  await handleStockInputKeyPress(e)
                }}
              />
            ) : (
              <S.StockContainer onClick={() => handleStockClick(datum.id, datum.stock)}>
                {datum.stock}
              </S.StockContainer>
            ),
        }))}
        headers={giftHeaders}
      />
    )
  }

  return (
    <S.Container>
      {updateLoading && <LoadingOverlay />}
      <S.HeaderContainer>
        <S.Title>Manage Gifts</S.Title>
      </S.HeaderContainer>
      {renderGiftsTable()}
      <StatusModal
        isOpen={isOpen}
        isLoading={updateLoading}
        isError={updateError !== ''}
        toggle={toggle}
        title={updateError ? 'Update Stock Failed' : 'Update Stock Success'}
      />
    </S.Container>
  )
}

export default Gifts
