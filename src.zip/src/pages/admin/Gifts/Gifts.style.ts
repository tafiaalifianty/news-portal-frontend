import Input from '../../../components/common/Input'
import styled from 'styled-components'

export const Container = styled.div`
  background-color: white;
  padding: 10px;
  overflow-x: auto;
`

export const HeaderContainer = styled.div`
  padding: 30px;
  display: flex;
  align-items: center;
  justify-content: space-between;
`

export const Title = styled.p`
  font-family: 'Roboto', sans-serif;
  font-size: 1.25rem;
`

export const StockContainer = styled.div`
  &:hover {
    cursor: pointer;
  }
`

export const InputStock = styled(Input)`
  background-color: transparent;
  padding: 10px;
  font-size: 0.9rem;
  font-weight: 400;
  font-family: 'Roboto';
  border: 1px solid var(--border);
  border-radius: 10px;
  width: 100px;
`
