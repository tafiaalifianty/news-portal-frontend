import Table, { TableHeader } from '../../../components/admin/Table/Table'
import Dropdown from '../../../components/common/Dropdown'
import Spinner from '../../../components/common/Spinner'
import StatusModal from '../../../components/common/StatusModal'
import useModal from '../../../hooks/useModal'
import moment from 'moment'
import React, { useState } from 'react'
import { useGetAllUserRewardsQuery, useUpdateRewardStatusMutation } from '../../../store/api/gift'
import { UserGift } from '../../../types/Gift'
import * as S from './Rewards.style'

const rewardsHeader: TableHeader[] = [
  { value: 'Email', name: 'user_email' },
  { value: 'Gift', name: 'gift_name' },
  { value: 'Status', name: 'status_update' },
  { value: 'Month Acquired', name: 'month_acquired' },
]

const Rewards = () => {
  const { data, isLoading, error } = useGetAllUserRewardsQuery()
  const [updateRewardStatus, { isLoading: updateLoading }] = useUpdateRewardStatusMutation()
  const [updateError, setUpdateError] = useState<string>('')
  const { isOpen, toggle } = useModal()

  const onDropdownChange = async (newStatus: string, reward: UserGift) => {
    if (newStatus === 'PROCESSED') {
      return
    }

    const successPayload = newStatus === 'COMPLETED'
    const id = `${reward.user_id}-${reward.gift_id}-${reward.month}-${reward.year}`

    try {
      await updateRewardStatus({
        id,
        isSuccess: successPayload,
      }).unwrap()
    } catch (err) {
      setUpdateError('Something went wrong. Please try again later')
    } finally {
      toggle()
    }
  }

  const renderRewardsTable = () => {
    if (isLoading) {
      return <Spinner />
    }

    if (!data || error) {
      return <p>Something went wrong</p>
    }

    return (
      <Table
        data={data.map((datum) => ({
          ...datum,
          status_update:
            datum.status === 'PROCESSED' ? (
              <Dropdown
                options={[
                  { value: 'PROCESSED', text: 'PROCESSED' },
                  { value: 'COMPLETED', text: 'COMPLETED' },
                  { value: 'REJECTED', text: 'REJECTED' },
                ]}
                onChange={async (e) => {
                  if (datum.status !== 'PROCESSED') return
                  await onDropdownChange(e.target.value, datum)
                }}
                dropdownStyle={{
                  backgroundColor: 'transparent',
                  padding: 0,
                  fontSize: '0.9rem',
                  fontWeight: 400,
                  color: '#2a2a2a',
                  fontFamily: 'Roboto',
                  width: '150px',
                }}
              />
            ) : (
              datum.status
            ),
          month_acquired: moment(`${datum.year}-${datum.month}`).format('MMMM YYYY'),
        }))}
        headers={rewardsHeader}
      />
    )
  }

  return (
    <S.Container>
      <S.HeaderContainer>
        <S.Title>Manage Rewards</S.Title>
      </S.HeaderContainer>
      {renderRewardsTable()}
      <StatusModal
        isOpen={isOpen}
        isLoading={updateLoading}
        isError={updateError !== ''}
        toggle={toggle}
        title={updateError ? 'Update Status Failed' : 'Update Status Success'}
      />
    </S.Container>
  )
}

export default Rewards
