import styled from 'styled-components'

export const Container = styled.div`
  background-color: white;
  padding: 10px;
  overflow-x: auto;
`

export const HeaderContainer = styled.div`
  padding: 30px;
  display: flex;
  align-items: center;
  justify-content: space-between;
`

export const Title = styled.p`
  font-family: 'Roboto', sans-serif;
  font-size: 1.25rem;
`
