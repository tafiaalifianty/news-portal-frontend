export { default } from './Rewards'
