import styled from 'styled-components'

export const Container = styled.div`
  font-family: 'Roboto', sans-serif;
`

export const Header = styled.h1`
  font-size: 1.5rem;
  font-weight: 500;
  margin-bottom: 40px;
`

export const ErrorText = styled.span`
  color: red;
  margin-top: 10px;
  text-align: center;
  display: block;
`
