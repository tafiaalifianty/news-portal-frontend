import * as Yup from 'yup'

const validationSchema = Yup.object().shape({
  title: Yup.string().required('Title is required'),
  summary: Yup.string().required('Summary is required'),
  content: Yup.string().required('Content is required'),
  type_id: Yup.number().required('Type is required'),
  category_id: Yup.number().required('Category is required'),
  image: Yup.mixed().required('File is required'),
  author_name: Yup.string().required('Author Name is required'),
})

export default validationSchema
