import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithProviders } from '../../../helpers/TestHelpers'
import { BrowserRouter, Router } from 'react-router-dom'
import AddPost from './AddPost'
import { rest } from 'msw'
import { setupServer } from 'msw/node'
import { ResponseData } from '../../../types/Response'
import { createMemoryHistory } from 'history'

const renderDefault = () => {
  renderWithProviders(
    <BrowserRouter>
      <AddPost />
    </BrowserRouter>
  )
}

const typeValidInputs = async () => {
  const inputs: Array<{ placeholder: string; value: string }> = [
    { placeholder: 'Title', value: 'Title' },
    { placeholder: 'Summary', value: 'Summary' },
    { placeholder: 'Content', value: 'Content' },
    { placeholder: 'Author Name', value: 'Author Name' },
  ]

  for (const input of inputs) {
    const inputElement = screen.getByPlaceholderText(input.placeholder)
    userEvent.type(inputElement, input.value)
    await waitFor(() => {
      expect(inputElement).toHaveValue(input.value)
    })
  }
}

describe('AddPost Page', () => {
  describe('Validation', () => {
    test.each`
      placeholder
      ${'Title'}
      ${'Summary'}
      ${'Content'}
      ${'Author Name'}
    `('should show error if input $placeholder is empty', async ({ placeholder }) => {
      renderDefault()

      const input = screen.getByPlaceholderText(placeholder)
      expect(input).toHaveValue('')

      const submitBtn = screen.getByRole('button', { name: 'Add Post' })
      userEvent.click(submitBtn)
      await waitFor(() => {
        expect(screen.getByText(`${placeholder} is required`)).toBeInTheDocument()
      })
    })
  })
  describe('onSubmit', () => {
    const server = setupServer()
    beforeAll(() => {
      server.listen()
    })
    afterEach(() => {
      server.resetHandlers()
    })
    afterAll(() => server.close())
    test('should show fields error on failed request with code 400', async () => {
      server.use(
        rest.post(`${process.env.REACT_APP_BASE_URL}/admin/posts`, async (req, res, ctx) => {
          const responseData: ResponseData = {
            code: 400,
            message: 'Bad Request',
            data: null,
          }
          return await res(ctx.status(400), ctx.json(responseData))
        })
      )

      renderDefault()
      await typeValidInputs()

      const submitBtn = screen.getByRole('button', { name: 'Add Post' })
      userEvent.click(submitBtn)
      await waitFor(() => {
        expect(screen.getByText('Please enter the fields correctly')).toBeInTheDocument()
      })
    })

    test('should show general error on failed request with code other than 400', async () => {
      server.use(
        rest.post(`${process.env.REACT_APP_BASE_URL}/admin/posts`, async (req, res, ctx) => {
          const responseData: ResponseData = {
            code: 500,
            message: 'Bad Request',
            data: null,
          }
          return await res(ctx.status(500), ctx.json(responseData))
        })
      )

      renderDefault()
      await typeValidInputs()

      const submitBtn = screen.getByRole('button', { name: 'Add Post' })
      userEvent.click(submitBtn)
      await waitFor(() => {
        expect(screen.getByText('Something went wrong. Please try again later')).toBeInTheDocument()
      })
    })

    test('should show general error on failed request with code other than 400', async () => {
      server.use(
        rest.post(`${process.env.REACT_APP_BASE_URL}/admin/posts`, async (req, res, ctx) => {
          return await res(ctx.status(200))
        })
      )

      const history = createMemoryHistory()
      history.push('/random-route')
      renderWithProviders(
        <Router
          location={history.location}
          navigator={history}
        >
          <AddPost />
        </Router>
      )
      await typeValidInputs()

      const submitBtn = screen.getByRole('button', { name: 'Add Post' })
      userEvent.click(submitBtn)
      await waitFor(
        () => {
          expect(history.location.pathname).toBe('/admin')
        },
        { timeout: 10000 }
      )
    })
  })
})
