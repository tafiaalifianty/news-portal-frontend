export { default } from './AddPost'
