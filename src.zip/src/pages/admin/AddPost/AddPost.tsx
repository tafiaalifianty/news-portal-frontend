import Form, { FormFieldConfig } from '../../../components/common/Form'
import LoadingOverlay from '../../../components/common/LoadingOverlay'
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  AddPostRequest,
  useAddPostMutation,
  useGetPostCategoriesQuery,
  useGetPostTypesQuery,
} from '../../../store/api/post'
import Response from '../../../types/Response'
import * as S from './AddPost.style'
import validationSchema from './validationSchema'
import axios from 'axios'
import Spinner from '../../../components/common/Spinner'

interface FormValues {
  title: string
  summary: string
  content: string
  type_id: string | number
  category_id: string | number
  image: File | undefined
  author_name: string
}

const AddPost = () => {
  const [value] = useState<FormValues>({
    title: '',
    summary: '',
    content: '',
    type_id: '1',
    category_id: '1',
    image: undefined,
    author_name: '',
  })
  const [fields, setFields] = useState<FormFieldConfig[]>([])
  const [addPost, { error }] = useAddPostMutation()
  const { data: types, isLoading: typesLoading, error: typesError } = useGetPostTypesQuery()
  const {
    data: categories,
    isLoading: categoriesLoading,
    error: categoriesError,
  } = useGetPostCategoriesQuery()
  const navigate = useNavigate()
  const [loading, setLoading] = useState<boolean>(false)

  useEffect(() => {
    if (!typesLoading && types && !categoriesLoading && categories) {
      setFields([
        {
          name: 'title',
          placeholder: 'Title',
        },
        {
          name: 'summary',
          placeholder: 'Summary',
          fieldType: 'textarea',
        },
        {
          name: 'content',
          placeholder: 'Content',
          fieldType: 'textarea',
        },
        {
          name: 'type_id',
          placeholder: 'Type',
          fieldType: 'dropdown',
          options: types?.map((postType) => ({ text: postType.name, value: postType.id })),
        },
        {
          name: 'category_id',
          placeholder: 'Category',
          fieldType: 'dropdown',
          options: categories?.map((category) => ({ text: category.name, value: category.id })),
        },
        {
          name: 'image',
          placeholder: 'Image',
          fieldType: 'file',
        },
        {
          name: 'author_name',
          placeholder: 'Author Name',
        },
      ])
    }
  }, [typesLoading, categoriesLoading])

  const renderError = () => {
    if (!error) return
    const errorCasted = error as Response
    if (errorCasted.data.code === 400) {
      return <S.ErrorText>Please enter the fields correctly</S.ErrorText>
    } else {
      return <S.ErrorText>Something went wrong. Please try again later</S.ErrorText>
    }
  }

  const uploadImage = async (file: File | undefined) => {
    if (!file) {
      throw new Error('File not uploaded')
    }
    const formData = new FormData()
    formData.append('file', file)
    formData.append('upload_preset', 'diginews')
    return await axios
      .post(
        `https://api.cloudinary.com/v1_1/${process.env.REACT_APP_CLOUDINARY_CLOUD_NAME}/image/upload`,
        formData
      )
      .then((response) => {
        return response.data.secure_url
      })
  }

  const onSubmitHandler = async (values: FormValues) => {
    setLoading(true)
    try {
      const url = await uploadImage(values.image)
      if (typeof values.category_id === 'string') {
        values.category_id = parseInt(values.category_id)
      }
      if (typeof values.type_id === 'string') {
        values.type_id = parseInt(values.type_id)
      }
      const addPostRequestBody: AddPostRequest = {
        ...values,
        img_url: url,
      }
      await addPost(addPostRequestBody).unwrap()
      navigate('/admin')
    } catch (error) {
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  if (typesLoading || categoriesLoading) {
    return <Spinner />
  }

  if ((!types || !categories || categoriesError) ?? typesError) {
    return <p>Something went wrong</p>
  }

  return (
    <S.Container>
      <S.Header>Add Post</S.Header>
      <Form
        initialValues={value}
        formFieldConfigs={fields}
        validationSchema={validationSchema}
        onSubmit={onSubmitHandler}
        btnText='Add Post'
      />
      {loading && <LoadingOverlay />}
      {renderError()}
    </S.Container>
  )
}

export default AddPost
