import Table from '../../../components/admin/Table'
import { TableHeader } from '../../../components/admin/Table/Table'
import Dropdown from '../../../components/common/Dropdown'
import Modal from '../../../components/common/Modal'
import useModal from '../../../hooks/useModal'
import { useState } from 'react'
import { useGetAllInvoiceQuery, useUpdateProcessedInvoiceMutation } from '../../../store/api/invoice'
import * as S from './Invoices.style'
import { ReactComponent as IconSuccess } from '../../../assets/img/ic_success.svg'
import { ReactComponent as IconFailed } from '../../../assets/img/ic_failed.svg'
import LoadingOverlay from '../../../components/common/LoadingOverlay'
import Spinner from '../../../components/common/Spinner'

const invoiceHeaders: TableHeader[] = [
  { value: 'ID', name: 'id' },
  { value: 'Code', name: 'code' },
  { value: 'Email', name: 'user_email' },
  { value: 'Subscription', name: 'subscription_plan' },
  { value: 'Total', name: 'total' },
  { value: 'Status', name: 'status_update' },
]

const Invoices = () => {
  const { data, isLoading, error } = useGetAllInvoiceQuery()
  const [updateProcessedInvoice, { isLoading: updateLoading }] = useUpdateProcessedInvoiceMutation()
  const { isOpen, toggle } = useModal()
  const [updateError, setUpdateError] = useState<string>('')

  const onDropdownChange = async (newStatus: string, invoiceCode: string) => {
    if (newStatus === 'PROCESSED') {
      return
    }

    const successPayload = newStatus === 'COMPLETED'
    try {
      await updateProcessedInvoice({
        code: invoiceCode,
        isSuccess: successPayload,
      }).unwrap()
      toggle()
    } catch (err) {
      setUpdateError('Something went wrong. Please try again later')
      toggle()
    }
  }

  const renderInvoicesList = () => {
    if (isLoading) {
      return <Spinner />
    }

    if (!data || error) {
      return <p>Something went wrong</p>
    }

    return (
      <Table
        data={data.map((datum) => ({
          ...datum,
          status_update:
            datum.status === 'PROCESSED' ? (
              <Dropdown
                options={[
                  { value: 'PROCESSED', text: 'PROCESSED' },
                  { value: 'COMPLETED', text: 'COMPLETED' },
                  { value: 'REJECTED', text: 'REJECTED' },
                ]}
                onChange={async (e) => {
                  await onDropdownChange(e.target.value, datum.code)
                }}
                dropdownStyle={{
                  backgroundColor: 'transparent',
                  padding: 0,
                  fontSize: '0.9rem',
                  fontWeight: 400,
                  color: '#2a2a2a',
                  fontFamily: 'Roboto',
                }}
              />
            ) : (
              datum.status
            ),
        }))}
        headers={invoiceHeaders}
      />
    )
  }

  return (
    <S.Container>
      {updateLoading && <LoadingOverlay />}
      <S.HeaderContainer>
        <S.Title>Invoices</S.Title>
        <S.FilterContainer></S.FilterContainer>
      </S.HeaderContainer>
      {renderInvoicesList()}
      <Modal
        isOpen={isOpen && !updateLoading}
        toggle={toggle}
      >
        <S.InnerModalContainer>
          <S.ModalTitle>Update {updateError ? 'Failed' : 'Success'}</S.ModalTitle>
          {updateError ? <IconFailed /> : <IconSuccess />}
        </S.InnerModalContainer>
      </Modal>
    </S.Container>
  )
}

export default Invoices
