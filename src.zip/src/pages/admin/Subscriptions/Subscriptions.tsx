import Table, { TableHeader } from '../../../components/admin/Table/Table'
import Spinner from '../../../components/common/Spinner'
import { useGetSubscriptionsQuery } from '../../../store/api/subscription'
import * as S from './Subscriptions.style'

const subscriptionHeaders: TableHeader[] = [
  { value: 'ID', name: 'id' },
  { value: 'Name', name: 'name' },
  { value: 'Price', name: 'price' },
  { value: 'Quota', name: 'quota' },
]

const Subscriptions = () => {
  const { data, isLoading, error } = useGetSubscriptionsQuery()

  const renderSubscriptionsTable = () => {
    if (isLoading) {
      return <Spinner />
    }

    if (!data || error) {
      return <p>Something went wrong</p>
    }

    return (
      <Table
        data={data}
        headers={subscriptionHeaders}
      />
    )
  }

  return (
    <S.Container>
      <S.HeaderContainer>
        <S.Title>Manage Subscriptions</S.Title>
      </S.HeaderContainer>
      {renderSubscriptionsTable()}
    </S.Container>
  )
}

export default Subscriptions
