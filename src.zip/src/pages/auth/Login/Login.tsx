import * as S from './Login.style'
import { useState } from 'react'
import Form, { FormFieldConfig } from '../../../components/common/Form'
import validationSchema from './validationSchema'
import { useLoginMutation } from '../../../store/api/auth'
import { Navigate, useNavigate } from 'react-router-dom'
import useAppSelector from '../../../hooks/useAppSelector'
import Response from '../../../types/Response'

interface LoginFormValue {
  email: string
  password: string
}

const LoginFormFieldConfigs: FormFieldConfig[] = [
  {
    name: 'email',
    placeholder: 'Email',
  },
  {
    name: 'password',
    placeholder: 'Password',
    inputType: 'password',
  },
]

const Login = () => {
  const [value] = useState<LoginFormValue>({
    email: '',
    password: '',
  })
  const [login, { isLoading: loginLoading, error: loginError }] = useLoginMutation()
  const navigate = useNavigate()
  const { isAuthenticated } = useAppSelector((state) => state.auth)

  const onSubmitHandler = async (values: LoginFormValue) => {
    try {
      await login(values).unwrap()
      navigate('/')
    } catch (error) {
      console.error(error)
    }
  }

  const renderError = () => {
    if (!loginError) {
      return ''
    }
    let errorText = 'Something went wrong. Please try again later'
    const loginErrorRecasted = loginError as Response
    if (loginErrorRecasted.data.message !== 'Bad Request' && loginErrorRecasted.data.code !== 500) {
      errorText = loginErrorRecasted.data.message
    }
    return <S.ErrorText>{errorText}</S.ErrorText>
  }

  if (isAuthenticated) {
    return <Navigate to='/' />
  }

  return (
    <S.Container>
      <S.FormContainer>
        <S.Header>
          <S.Image
            src={require('../../../assets/img/logo.png')}
            alt='Logo'
          />
        </S.Header>
        <Form
          initialValues={value}
          formFieldConfigs={LoginFormFieldConfigs}
          validationSchema={validationSchema}
          onSubmit={onSubmitHandler}
          btnText='Login'
          btnDisable={loginLoading}
        />
      </S.FormContainer>
      <S.SignUpRedirect>
        You dont have an account?{' '}
        <S.SignUpHighlight onClick={() => navigate('/register')}>SignUp</S.SignUpHighlight>
      </S.SignUpRedirect>
      {renderError()}
    </S.Container>
  )
}

export default Login
