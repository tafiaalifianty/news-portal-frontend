import styled from 'styled-components'

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
`

export const FormContainer = styled.div`
  max-width: 400px;
`

export const Image = styled.img`
  width: 100%;
`

export const Header = styled.div`
  margin-bottom: 25px;
`

export const Form = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  width: 100%;
`

export const ErrorText = styled.span`
  color: red;
  margin-top: 10px;
  font-size: 0.75rem;
`

export const LoginRedirect = styled.p`
  color: #999;
  font-size: 0.9rem;
  margin-top: 10px;
`

export const LoginHighlight = styled.span`
  font-weight: 700;
  cursor: pointer;
`
