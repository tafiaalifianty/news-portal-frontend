import { screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { BrowserRouterWrapper, renderWithProviders } from '../../../helpers/TestHelpers'
import Register from './Register'
import { rest } from 'msw'
import { setupServer } from 'msw/node'
import { createMemoryHistory } from 'history'
import { Router } from 'react-router-dom'
import { act } from 'react-dom/test-utils'
import User from '../../../types/User'
import { ResponseData } from '../../../types/Response'

const typeValidInputs = async () => {
  const validEmail = 'email@email.com'
  const validFullname = 'fullname'
  const validAddress = 'address'
  const validPassword = 'password'

  const emailInput = screen.getByPlaceholderText(/email/i)
  userEvent.type(emailInput, validEmail)
  await waitFor(() => {
    expect(emailInput).toHaveValue()
  })

  const fullnameInput = screen.getByPlaceholderText(/full name/i)
  userEvent.type(fullnameInput, validFullname)
  await waitFor(() => {
    expect(fullnameInput).toHaveValue()
  })

  const addressInput = screen.getByPlaceholderText(/address/i)
  userEvent.type(addressInput, validAddress)
  await waitFor(() => {
    expect(addressInput).toHaveValue()
  })

  const passwordInput = screen.getByPlaceholderText('Password')
  userEvent.type(passwordInput, validPassword)
  await waitFor(() => {
    expect(passwordInput).toHaveValue(validPassword)
  })

  const confirmPasswordInput = screen.getByPlaceholderText('Confirm Password')
  userEvent.type(confirmPasswordInput, validPassword)
  await waitFor(() => {
    expect(confirmPasswordInput).toHaveValue()
  })
}

describe('Register Page', () => {
  describe('Validation', () => {
    test('should show error if email is empty', async () => {
      renderWithProviders(
        <BrowserRouterWrapper>
          <Register />
        </BrowserRouterWrapper>
      )

      const emailInput = screen.getByPlaceholderText(/email/i)
      expect(emailInput).toHaveValue('')

      const submitBtn = screen.getByRole('button', { name: 'Register' })
      userEvent.click(submitBtn)
      await waitFor(() => {
        expect(screen.getByText('Email is required')).toBeInTheDocument()
      })
    })

    test('should show error if email is invalid', async () => {
      const invalidEmail = 'invalid_email'

      renderWithProviders(
        <BrowserRouterWrapper>
          <Register />
        </BrowserRouterWrapper>
      )

      const emailInput = screen.getByPlaceholderText(/email/i)
      userEvent.type(emailInput, invalidEmail)

      const submitBtn = screen.getByRole('button', { name: 'Register' })
      userEvent.click(submitBtn)
      await waitFor(() => {
        expect(screen.getByText('Invalid email format')).toBeInTheDocument()
      })
    })

    test('should show error if address is empty', async () => {
      renderWithProviders(
        <BrowserRouterWrapper>
          <Register />
        </BrowserRouterWrapper>
      )

      const addressInput = screen.getByPlaceholderText('Address')
      expect(addressInput).toHaveValue('')

      const submitBtn = screen.getByRole('button', { name: 'Register' })
      userEvent.click(submitBtn)
      await waitFor(() => {
        expect(screen.getByText('Address is required')).toBeInTheDocument()
      })
    })

    test('should show error if password is empty', async () => {
      renderWithProviders(
        <BrowserRouterWrapper>
          <Register />
        </BrowserRouterWrapper>
      )

      const passwordInput = screen.getByPlaceholderText('Password')
      expect(passwordInput).toHaveValue('')

      const submitBtn = screen.getByRole('button', { name: 'Register' })
      userEvent.click(submitBtn)
      await waitFor(() => {
        expect(screen.getByText('Password is required')).toBeInTheDocument()
      })
    })

    test('should show error if confirmPassword is empty', async () => {
      renderWithProviders(
        <BrowserRouterWrapper>
          <Register />
        </BrowserRouterWrapper>
      )

      const confirmPasswordInput = screen.getByPlaceholderText('Confirm Password')
      expect(confirmPasswordInput).toHaveValue('')

      const submitBtn = screen.getByRole('button', { name: 'Register' })
      userEvent.click(submitBtn)
      await waitFor(() => {
        expect(screen.getByText('Confirm Password is required')).toBeInTheDocument()
      })
    })

    test('should show error if password and confirmPassword does not match', async () => {
      const password = 'password'
      const differentPassword = 'different_password'
      renderWithProviders(
        <BrowserRouterWrapper>
          <Register />
        </BrowserRouterWrapper>
      )

      const passwordInput = screen.getByPlaceholderText('Password')
      userEvent.type(passwordInput, password)
      await waitFor(() => {
        expect(passwordInput).toHaveValue(password)
      })

      const confirmPasswordInput = screen.getByPlaceholderText('Confirm Password')
      userEvent.type(confirmPasswordInput, differentPassword)
      await waitFor(() => {
        expect(confirmPasswordInput).toHaveValue(differentPassword)
      })

      const submitBtn = screen.getByRole('button', { name: 'Register' })
      userEvent.click(submitBtn)
      await waitFor(() => {
        expect(screen.getByText('Passwords must match')).toBeInTheDocument()
      })
    })
  })

  describe('onSubmit', () => {
    const server = setupServer()
    beforeAll(() => {
      server.listen()
    })
    afterEach(() => {
      server.resetHandlers()
    })
    afterAll(() => server.close())

    test('should show error on failed register request', async () => {
      server.use(
        rest.post(`${process.env.REACT_APP_BASE_URL}/register`, async (req, res, ctx) => {
          const responseData: ResponseData = {
            code: 400,
            message: 'wrong email or password',
            data: null,
          }
          return await res(ctx.status(400), ctx.json(responseData))
        })
      )

      renderWithProviders(
        <BrowserRouterWrapper>
          <Register />
        </BrowserRouterWrapper>
      )
      await typeValidInputs()

      const submitBtn = screen.getByRole('button', { name: 'Register' })
      act(() => {
        userEvent.click(submitBtn)
      })
      await waitFor(() => {
        expect(screen.getByText('wrong email or password')).toBeInTheDocument()
      })
    })

    test('should navigate to / on success', async () => {
      server.use(
        rest.post(`${process.env.REACT_APP_BASE_URL}/register`, async (req, res, ctx) => {
          await new Promise((resolve) => {
            setTimeout(() => {
              resolve('')
            }, 1000)
          })

          return await res(
            ctx.json({
              data: {
                id: 1,
                email: '',
                token: '',
              },
            })
          )
        }),
        rest.get(`${process.env.REACT_APP_BASE_URL}/users/profile`, async (req, res, ctx) => {
          const mockUser: User = {
            id: 1,
            email: '',
            role: 'member',
            fullname: '',
            address: '',
          }
          return await res(
            ctx.json({
              data: mockUser,
            })
          )
        })
      )

      const history = createMemoryHistory()
      history.push('/random-route')
      renderWithProviders(
        <Router
          location={history.location}
          navigator={history}
        >
          <Register />
        </Router>
      )
      await typeValidInputs()

      const submitBtn = screen.getByRole('button', { name: 'Register' })
      act(() => {
        userEvent.click(submitBtn)
      })
      await waitFor(() => {
        expect(submitBtn).toBeDisabled()
      })

      await waitFor(
        () => {
          expect(history.location.pathname).toBe('/')
        },
        { timeout: 10000 }
      )
    })
  })
})
