import * as S from './Register.style'
import { useState } from 'react'
import Form, { FormFieldConfig } from '../../../components/common/Form'
import validationSchema from './validationSchema'
import { useRegisterMutation } from '../../../store/api/auth'
import { Navigate, useNavigate } from 'react-router-dom'
import Response from '../../../types/Response'
import useAppSelector from '../../../hooks/useAppSelector'

interface RegisterFormValue {
  email: string
  password: string
  confirmPassword: string
  fullName: string
  address: string
  referral_code: string
}

const RegisterFormFieldConfigs: FormFieldConfig[] = [
  {
    name: 'email',
    placeholder: 'Email',
  },
  {
    name: 'fullName',
    placeholder: 'Full Name',
  },
  {
    name: 'address',
    placeholder: 'Address',
  },
  {
    name: 'password',
    placeholder: 'Password',
    inputType: 'password',
  },
  {
    name: 'confirmPassword',
    placeholder: 'Confirm Password',
    inputType: 'password',
  },
  {
    name: 'referral_code',
    placeholder: 'Referral Code',
  },
]

const Register = () => {
  const [value] = useState<RegisterFormValue>({
    email: '',
    password: '',
    confirmPassword: '',
    address: '',
    fullName: '',
    referral_code: '',
  })
  const [register, { isLoading: registerLoading, error: registerError }] = useRegisterMutation()
  const navigate = useNavigate()
  const { isAuthenticated } = useAppSelector((state) => state.auth)

  const onSubmitHandler = async (values: RegisterFormValue) => {
    try {
      await register(values).unwrap()
      navigate('/')
    } catch (error) {
      console.error(error)
    }
  }

  const renderError = () => {
    if (!registerError) {
      return ''
    }
    let errorText = 'Something went wrong. Please try again later'
    const registerErrorRecasted = registerError as Response
    if (
      registerErrorRecasted.data.message !== 'Bad Request' &&
      registerErrorRecasted.data.code !== 500
    ) {
      errorText = registerErrorRecasted.data.message
    }
    return <S.ErrorText>{errorText}</S.ErrorText>
  }

  if (isAuthenticated) {
    return <Navigate to='/' />
  }

  return (
    <S.Container>
      <S.FormContainer>
        <S.Header>
          <S.Image
            src={require('../../../assets/img/logo.png')}
            alt='Logo'
          />
        </S.Header>
        <Form
          initialValues={value}
          formFieldConfigs={RegisterFormFieldConfigs}
          validationSchema={validationSchema}
          onSubmit={onSubmitHandler}
          btnText='Register'
          btnDisable={registerLoading}
        />
      </S.FormContainer>
      <S.LoginRedirect>
        Already have an account?{' '}
        <S.LoginHighlight onClick={() => navigate('/login')}>Login</S.LoginHighlight>
      </S.LoginRedirect>
      {renderError()}
    </S.Container>
  )
}

export default Register
