import styled from 'styled-components'

export const App = styled.div``
