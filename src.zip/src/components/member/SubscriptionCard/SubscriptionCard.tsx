import Button from '../../../components/common/Button'
import { formatRp } from '../../../helpers/Number'
import Subscription from '../../../types/Subscription'
import * as S from './SubscriptionCard.style'

interface SubscriptionCardProps {
  subscription: Subscription
  onClick: () => void
}

const SubscriptionCard = ({ subscription, onClick }: SubscriptionCardProps) => {
  return (
    <S.Container>
      <S.Title>{subscription.name}</S.Title>
      <S.Price>{formatRp(subscription.price)}</S.Price>
      <S.Benefits>{subscription.quota} reading quota</S.Benefits>
      <Button onClick={onClick}>Get Started</Button>
    </S.Container>
  )
}

export default SubscriptionCard
