import styled from 'styled-components'

export const Container = styled.div`
  width: 100%;
  background-color: var(--on-primary);
  box-shadow: 0px 2px 14px rgba(42, 42, 42, 0.24);
  text-align: center;
  padding: 20px;
  border-radius: 5px;
`

export const Title = styled.h1`
  font-family: 'IBM Plex Serif', sans-serif;
  font-weight: 500;
  font-size: 1.5rem;
  margin-bottom: 20px;
`

export const Price = styled.p`
  font-size: 2.5rem;
  font-family: 'Poppins', serif;
  font-weight: 700;
  margin-bottom: 30px;
`

export const Benefits = styled.p`
  font-family: 'Nunito Sans', sans-serif;
  font-size: 1.25rem;
  margin-bottom: 30px;
`
