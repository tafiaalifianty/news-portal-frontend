import NoData from '../../../components/common/NoData'
import Spinner from '../../../components/common/Spinner'
import { formatRp } from '../../../helpers/Number'
import { useNavigate } from 'react-router-dom'
import { useGetUserInvoicesQuery } from '../../../store/api/invoice'
import Invoice from '../../../types/Invoice'
import StatusCard from '../StatusCard'
import * as S from './InvoiceTab.style'

const InvoiceTab = () => {
  const { data: invoices, isLoading, error } = useGetUserInvoicesQuery()
  const navigate = useNavigate()

  const onClick = (invoice: Invoice) => {
    if (invoice.status === 'WAITING') {
      navigate(`/payment/${invoice.code}`)
    }
  }

  const renderInvoices = () => {
    if (isLoading) {
      return <Spinner />
    }

    if (!invoices || error) {
      return <p>Something went wrong</p>
    }

    if (invoices.length === 0) {
      return <NoData text="You haven't made any purchase yet" />
    }

    return invoices.map((invoice) => (
      <StatusCard
        status={invoice.status}
        date={invoice.purchased_at}
        leftField='Subscription Plan:'
        leftValue={invoice.subscription_plan ?? ''}
        rightField={'Price:'}
        rightValue={formatRp(invoice.total)}
        key={invoice.id}
        onClick={() => onClick(invoice)}
      />
    ))
  }

  return <S.Container>{renderInvoices()}</S.Container>
}

export default InvoiceTab
