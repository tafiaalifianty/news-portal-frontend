import styled from 'styled-components'

export const Container = styled.div``

export const CardListsContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 2%;

  & > * {
    width: 49%;

    @media (max-width: 480px) {
      width: 100%;
    }
  }
`

export const CardContainer = styled.div`
  border: 1px solid var(--border);
  border-radius: 5px;
  padding: 5px 10px;
  transition: 250ms ease-out;
  display: flex;
  justify-content: space-between;

  &:hover {
    cursor: pointer;
    background-color: #EEEEEE;
  }
`

export const LeftContainer = styled.div``

export const Name = styled.p`
  font-family: var(--normal-text);
  font-weight: 700;
  font-size: 1.1rem;
  word-wrap: break-word;
`

export const Email = styled.p`
  font-family: var(--detail-text);
  font-size: 0.8rem;
  word-wrap: break-word;
`

export const RightContainer = styled.div`
  text-align: right;
`

export const Field = styled.p`
  font-family: var(--normal-text);
  font-size: 0.8rem;
  word-wrap: break-word;
`

export const Spending = styled.p`
  font-family: var(--normal-text);
  font-weight: 700;
  font-size: 1.1rem;
  word-wrap: break-word;
`
