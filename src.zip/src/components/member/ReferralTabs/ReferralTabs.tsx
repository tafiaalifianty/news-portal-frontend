import NoData from '../../../components/common/NoData'
import Spinner from '../../../components/common/Spinner'
import { formatRp } from '../../../helpers/Number'
import { useGetUserReferralsQuery } from '../../../store/api/user'
import * as S from './ReferralTabs.style'

const ReferralTabs = () => {
  const { data: referrals, isLoading, error } = useGetUserReferralsQuery()

  const renderReferrals = () => {
    if (isLoading) {
      return <Spinner />
    }

    if (!referrals || error) {
      return <p>Something went wrong</p>
    }

    if (referrals.length === 0) {
      return <NoData text='No users used your referral code yet' />
    }

    return (
      <S.CardListsContainer>
        {referrals.map((referral) => (
          <S.CardContainer key={referral.id}>
            <S.LeftContainer>
              <S.Name>{referral.fullname}</S.Name>
              <S.Email>{referral.email}</S.Email>
            </S.LeftContainer>
            <S.RightContainer>
              <S.Field>Spent:</S.Field>
              <S.Spending>{formatRp(referral.total_spending)}</S.Spending>
            </S.RightContainer>
          </S.CardContainer>
        ))}
      </S.CardListsContainer>
    )
  }

  return <S.Container>{renderReferrals()}</S.Container>
}

export default ReferralTabs
