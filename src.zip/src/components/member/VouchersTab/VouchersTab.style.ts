import styled from 'styled-components'

export const Container = styled.div``

export const VoucherListContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
`

export const CardContainer = styled.div`
  border: 1px solid var(--border);
  border-radius: 5px;
  padding: 5px 10px;
  transition: 250ms ease-out;

  &.invalid {
    opacity: 0.5;
  }
`

export const HeaderContainer = styled.div`
  display: flex;
  flex-direction: column;
  font-size: 0.9rem;
  font-family: var(--normal-text);
  border-bottom: 1px solid var(--border);
  padding-bottom: 5px;
`

export const ReceivedContainer = styled.div`
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
`

export const ReceivedField = styled.p``

export const ReceivedValue = styled.p`
  font-weight: 700;
`

export const BodyContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 0;
`

export const LeftContainer = styled.div`
  display: flex;
  flex-direction: column;
`

export const RightContainer = styled.div``

export const Code = styled.p`
  font-weight: 700;
  font-size: 1.3rem;
  margin-bottom: 10px;
`

export const Name = styled.p``

export const ValidUntil = styled.p``

export const Discount = styled.p`
  font-weight: 700;
  font-size: 1.1rem;
`

export const Field = styled.span`
  display: inline-block;
  font-size: 0.8rem;
  font-weight: 400;
`

export const IconContainer = styled.span`
  fill: #bfdbfe;

  &:hover {
    cursor: pointer;
    opacity: 0.5;
  }
`
