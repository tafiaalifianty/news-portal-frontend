import { formatRp } from '../../../helpers/Number'
import moment from 'moment'
import { useGetUserVouchersQuery } from '../../../store/api/user'
import * as S from './VouchersTab.style'
import { ReactComponent as CopyIcon } from '../../../assets/img/ic_copy.svg'
import NoData from '../../../components/common/NoData'
import Spinner from '../../../components/common/Spinner'

const VoucherTabs = () => {
  const { data: vouchers, isLoading, error } = useGetUserVouchersQuery()

  const onCopyClick = async (text: string) => {
    await await navigator.clipboard.writeText(text)
  }

  const renderVouchers = () => {
    if (isLoading) {
      return <Spinner />
    }

    if (!vouchers || error) {
      return <p>Something went wrong</p>
    }

    if (vouchers.length === 0) {
      return <NoData text="You haven't received any voucher yet" />
    }

    return (
      <S.VoucherListContainer>
        {vouchers.map((userVoucher) => (
          <S.CardContainer
            key={userVoucher.id}
            className={userVoucher.is_valid ? '' : 'invalid'}
          >
            <S.HeaderContainer>
              <S.ReceivedField> Received from: </S.ReceivedField>
              <S.ReceivedValue>{userVoucher.received_from_user_email}</S.ReceivedValue>
            </S.HeaderContainer>
            <S.BodyContainer>
              <S.LeftContainer>
                <S.Code>
                  {userVoucher.code}{' '}
                  {userVoucher.is_valid && (
                    <S.IconContainer
                      onClick={async () => {
                        await onCopyClick(userVoucher.code)
                      }}
                    >
                      <CopyIcon />
                    </S.IconContainer>
                  )}
                </S.Code>
                <S.Name>{userVoucher.voucher.name}</S.Name>
                <S.ValidUntil>
                  <S.Field>Valid until </S.Field>{' '}
                  {moment(userVoucher.valid_until).format('MMM Do, YYYY')}
                </S.ValidUntil>
              </S.LeftContainer>
              <S.RightContainer>
                <S.Discount>{formatRp(userVoucher.voucher.discount)}</S.Discount>
              </S.RightContainer>
            </S.BodyContainer>
          </S.CardContainer>
        ))}
      </S.VoucherListContainer>
    )
  }

  return <S.Container>{renderVouchers()}</S.Container>
}

export default VoucherTabs
