export { default } from './RewardsTab'
