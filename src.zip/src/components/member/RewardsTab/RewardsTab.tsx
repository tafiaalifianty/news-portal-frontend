import NoData from '../../../components/common/NoData'
import Spinner from '../../../components/common/Spinner'
import moment from 'moment'
import { useGetUserRewardsQuery } from '../../../store/api/user'
import StatusCard from '../StatusCard'
import * as S from './RewardsTab.style'

const RewardsTab = () => {
  const { data: rewards, isLoading, error } = useGetUserRewardsQuery()

  const renderRewards = () => {
    if (isLoading) {
      return <Spinner />
    }

    if (!rewards || error) {
      return <p>Something went wrong</p>
    }

    if (rewards.length === 0) {
      return <NoData text='No Rewards received yet' />
    }

    return rewards.map((reward) => (
      <StatusCard
        status={reward.status}
        leftField='Acquired At:'
        leftValue={moment(`${reward.year}-${reward.month}`).format('MMM, YYYY')}
        rightField='Gift:'
        rightValue={reward.gift_name}
        key={`${reward.user_id}-${reward.gift_id}-${reward.month}-${reward.year}`}
      />
    ))
  }

  return <S.Container>{renderRewards()}</S.Container>
}

export default RewardsTab
