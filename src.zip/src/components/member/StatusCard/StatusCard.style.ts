import styled from 'styled-components'
import { InvoiceStatus } from '../../../types/Invoice'

const statusBgColor: {
  [key in InvoiceStatus]: string
} = {
  WAITING: '#FEF08A',
  PROCESSED: '#BFDBFE',
  COMPLETED: '#BBF7D0',
  REJECTED: '#FECACA',
}

const statusTextColor: {
  [key in InvoiceStatus]: string
} = {
  WAITING: '#CA8A04',
  PROCESSED: '#2563EB',
  COMPLETED: '#16A34A',
  REJECTED: '#DC2626',
}

export const Container = styled.div`
  border: 1px solid var(--border);
  border-radius: 5px;
  padding: 5px 10px;
  transition: 250ms ease-out;

  &:hover {
    cursor: pointer;
    background-color: #eee;
  }
`

export const TopContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
  font-size: 0.9rem;
  border-bottom: 1px solid var(--border);
  padding-bottom: 5px;
`

export const MainContainer = styled.div`
  padding-top: 10px;
  display: flex;
  justify-content: space-between;
`

export const PurchasedAt = styled.p``

export const Status = styled.p<{ status: InvoiceStatus }>`
  text-transform: capitalize;
  background-color: ${(props) => statusBgColor[props.status]};
  color: ${(props) => statusTextColor[props.status]};
  font-weight: 500;
  font-family: var(--detail-text);
  padding: 2px 10px;
  border-radius: 5px;
`
export const FieldContainer = styled.div`
  &:last-child {
    text-align: right;
  }
`

export const FieldText = styled.p`
  font-family: var(--normal-text);
  font-size: 0.8rem;
`

export const Plan = styled.p`
  font-family: var(--normal-text);
  font-size: 1.1rem;
  font-weight: 700;
`

export const Price = styled.p`
  font-family: var(--normal-text);
  font-size: 1.1rem;
  font-weight: 700;
`
