import moment from 'moment'
import { InvoiceStatus } from '../../../types/Invoice'
import * as S from './StatusCard.style'

interface StatusCardProps {
  status?: string
  date?: string
  leftField?: string
  leftValue?: string
  rightField?: string
  rightValue?: string
  onClick?: () => void
}

const StatusCard = ({
  status = '',
  date,
  leftField = '',
  leftValue = '',
  rightField = '',
  rightValue = '',
  onClick = () => {},
}: StatusCardProps) => {
  return (
    <S.Container onClick={onClick}>
      <S.TopContainer>
        <S.PurchasedAt>{date ? moment(date).format('MMM Do, YYYY') : ''}</S.PurchasedAt>
        <S.Status status={status as InvoiceStatus}>{status.toLowerCase()}</S.Status>
      </S.TopContainer>
      <S.MainContainer>
        <S.FieldContainer>
          <S.FieldText>{leftField}</S.FieldText>
          <S.Plan>{leftValue}</S.Plan>
        </S.FieldContainer>
        <S.FieldContainer>
          <S.FieldText>{rightField}</S.FieldText>
          <S.Price>{rightValue}</S.Price>
        </S.FieldContainer>
      </S.MainContainer>
    </S.Container>
  )
}

export default StatusCard
