import Dropdown from '../../../components/common/Dropdown'
import Input from '../../../components/common/Input'
import styled from 'styled-components'

export const Container = styled.div`
  padding: 15px 20px;
  background-color: var(--primary);
  color: var(--on-primary);
  font-weight: bold;
  display: flex;
  gap: 20px;

  @media (max-width: 768px) {
    flex-direction: column;
    gap: 10px;
  }
`

export const Search = styled(Input)`
  border-radius: 10px;
  outline: none;
  border: none;
  padding: 5px 10px;
  flex: 1;
  background-color: var(--on-primary);
`

export const LeftContainer = styled.div`
  flex: 3;
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  @media (max-width: 768px) {
    flex-direction: column;
    gap: 10px;
  }
`

export const DropdownContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 5px;

  @media (max-width: 768px) {
    & > * {
      flex: 1;
    }
  }
`

export const DropdownFilter = styled(Dropdown)`
  background-color: var(--on-primary);
  padding: 5px 10px;
`

export const FilterLabel = styled.label`
  white-space: nowrap;
`
