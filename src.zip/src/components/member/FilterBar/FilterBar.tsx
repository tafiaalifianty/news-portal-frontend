import { DropdownOptions } from '../../../components/common/Dropdown/Dropdown'
import React, { useEffect, useState } from 'react'
import { useGetPostCategoriesQuery, useGetPostTypesQuery } from '../../../store/api/post'
import * as S from './FilterBar.style'

let searchTimeout: NodeJS.Timeout

interface FilterBarProps {
  onSearch: (arg0: string) => void
  onDateSort: (arg0: string) => void
  onCategoryFilter: (arg0: string) => void
  onTypeFilter: (arg0: string) => void
}

const sortDateOptions: DropdownOptions[] = [
  { text: 'Descending', value: 'desc' },
  { text: 'Ascending', value: 'asc' },
]

const defaultOption: DropdownOptions = {
  text: '--',
  value: '0',
}

const FilterBar = ({ onSearch, onDateSort, onCategoryFilter, onTypeFilter }: FilterBarProps) => {
  const [categoryOptions, setCategoryOptions] = useState<DropdownOptions[]>([defaultOption])
  const [typeOptions, setTypeOptions] = useState<DropdownOptions[]>([defaultOption])

  const { data: categories, isLoading: categoriesLoading } = useGetPostCategoriesQuery()
  const { data: types, isLoading: typesLoading } = useGetPostTypesQuery()

  useEffect(() => {
    if (!categoriesLoading && categories) {
      setCategoryOptions([
        defaultOption,
        ...categories.map((category) => ({ text: category.name, value: category.id })),
      ])
    }
  }, [categoriesLoading])

  useEffect(() => {
    if (!typesLoading && types) {
      setTypeOptions([defaultOption, ...types.map((type) => ({ text: type.name, value: type.id }))])
    }
  }, [typesLoading])

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    clearTimeout(searchTimeout)

    searchTimeout = setTimeout(() => {
      onSearch(e.target.value)
    }, 500)
  }

  const handleDateSort = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onDateSort(e.target.value)
  }

  const handleCategoryFilter = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onCategoryFilter(e.target.value)
  }

  const handleTypeFilter = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onTypeFilter(e.target.value)
  }

  return (
    <S.Container>
      <S.Search
        onChange={handleSearch}
        placeholder='Search news title...'
      />
      <S.LeftContainer>
        <S.DropdownContainer>
          <S.FilterLabel htmlFor='sort'>Sort Date</S.FilterLabel>
          <S.DropdownFilter
            name='sort'
            options={sortDateOptions}
            onChange={handleDateSort}
          />
        </S.DropdownContainer>
        <S.DropdownContainer>
          <S.FilterLabel htmlFor='category'>Category:</S.FilterLabel>
          <S.DropdownFilter
            name='category'
            options={categoryOptions}
            onChange={handleCategoryFilter}
          />
        </S.DropdownContainer>
        <S.DropdownContainer>
          <S.FilterLabel htmlFor='type'>Type:</S.FilterLabel>
          <S.DropdownFilter
            name='type'
            options={typeOptions}
            onChange={handleTypeFilter}
          />
        </S.DropdownContainer>
      </S.LeftContainer>
    </S.Container>
  )
}

export default FilterBar
