import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import Post from '../../../types/Post'
import PostCard from './PostCard'

const mockPost: Post = {
  id: 1,
  title: '',
  slug: '',
  content: '',
  summary: '',
  category_id: 0,
  category: '',
  type_id: 0,
  type: '',
  img_url: '',
  img_thumbnail: '',
  author_name: '',
  share_count: 0,
  like_count: 0,
  created_at: '',
}

describe('PostCard', () => {
  test('should run onClick on component click', async () => {
    const mockOnClick = jest.fn()
    render(
      <PostCard
        post={mockPost}
        onClick={mockOnClick}
      />
    )

    userEvent.click(screen.getByTestId('post-card'))
    await waitFor(() => {
      expect(mockOnClick).toBeCalled()
    })
  })
})
