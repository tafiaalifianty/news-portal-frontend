import * as S from './Shimmer.style'

interface ShimmerProps {
  totalItems?: number
}

const Shimmer = ({ totalItems = 1 }: ShimmerProps) => {
  const renderShimmers = () => {
    const shimmers: React.ReactNode[] = []
    for (let i = 0; i < totalItems; i++) {
      shimmers.push(
        <S.Container key={i}>
          <S.BodyContainer>
            <S.Image />
            <S.ContentContainer>
              <S.Title />
              <div>
                <S.Summary />
                <S.Summary />
                <S.Summary />
                <S.Summary />
              </div>
            </S.ContentContainer>
          </S.BodyContainer>
          <S.FooterContainer />
        </S.Container>
      )
    }
    return shimmers
  }
  return <>{renderShimmers()}</>
}

export default Shimmer
