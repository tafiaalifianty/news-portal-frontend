import styled from 'styled-components'
import { BaseShimmer } from '../../../../styles/Shimer.style'

export const Container = styled.div`
  width: 100%;
  border-radius: 5px;
  background-color: var(--on-primary);
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  z-index: 0;
  box-shadow: 0px 2px 14px rgba(42, 42, 42, 0.24);
`

export const Image = styled(BaseShimmer)`
  width: 100%;
  height: auto;
  aspect-ratio: 2 / 1;
`

export const BodyContainer = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`

export const ContentContainer = styled.div`
  padding: 10px 25px;
  margin-bottom: 10px;
`

export const Title = styled(BaseShimmer)`
  margin-bottom: 25px;
  max-width: 200px;
  height: 1.5rem;
`

export const Summary = styled(BaseShimmer)`
  height: 0.9rem;
  margin-bottom: 5px;
`

export const FooterContainer = styled(BaseShimmer)`
  padding: 10px 25px;
  height: 2rem;
`
