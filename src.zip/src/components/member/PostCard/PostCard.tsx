import Post from '../../../types/Post'
import * as S from './PostCard.style'
import { ReactComponent as UnlikedIcon } from '../../../assets/img/post/ic_unliked.svg'
import { ReactComponent as UnsharedIcon } from '../../../assets/img/post/ic_unshared.svg'
import moment from 'moment'

interface PostCardProps {
  post: Post
  onClick: () => void
  isCompact?: boolean
}

const PostCard = ({ post, onClick, isCompact = false }: PostCardProps) => {
  return (
    <S.Container
      onClick={onClick}
      data-testid='post-card'
      is_compact={isCompact}
    >
      <S.Type>{post.type}</S.Type>
      <S.Body>
        <S.Image src={post.img_thumbnail} />
        <S.Content>
          <S.Title isCompact={isCompact}>{post.title}</S.Title>
          <S.Category>{post.category}</S.Category>
          {!isCompact && <S.Summary>{post.summary}</S.Summary>}
        </S.Content>
      </S.Body>
      <S.Footer>
        {!isCompact && (
          <S.Detail>
            <S.DatePublished>{moment(post.created_at).format('MMMM Do YYYY')}</S.DatePublished>
            <S.Author>By {post.author_name}</S.Author>
          </S.Detail>
        )}
        <S.InteractionContainer>
          <S.Interaction>
            <UnlikedIcon />
            <span>{post.like_count}</span>
          </S.Interaction>
          <S.Interaction>
            <UnsharedIcon />
            <span>{post.share_count}</span>
          </S.Interaction>
        </S.InteractionContainer>
      </S.Footer>
    </S.Container>
  )
}

export default PostCard
