import styled from 'styled-components'

export const Container = styled.div<{ is_compact: boolean }>`
  width: 100%;
  max-width: ${(props) => (props.is_compact ? '300px' : '100%')};
  border-radius: 5px;
  background-color: var(--on-primary);
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  position: relative;
  z-index: 0;
  transition: 250ms ease-out;
  box-shadow: 0px 2px 14px rgba(42, 42, 42, 0.24);

  &:hover {
    cursor: pointer;
    transform: translateY(-10px);
  }
`

export const Type = styled.div`
  position: absolute;
  top: 10px;
  right: 10px;
  padding: 5px 10px;
  font-weight: bold;
  color: var(--on-primary);
  background-color: var(--primary);
  border-radius: 5px;
`

export const Image = styled.img`
  width: 100%;
  height: auto;
  aspect-ratio: 2 / 1;
  object-fit: cover;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
`

export const Body = styled.div`
  font-size: 1rem;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`

export const Content = styled.div`
  padding: 10px 25px;
  margin-bottom: 10px;
`

export const Title = styled.h2<{ isCompact?: boolean }>`
  font-family: 'IBM Plex Serif', sans-serif;
  font-weight: 500;
  margin-bottom: 5px;
  font-size: ${(props) => (props.isCompact ? '1rem' : '1.5rem')};
`
export const Category = styled.div`
  font-size: 0.75rem;
  color: var(--text-muted);
`

export const Summary = styled.p`
  font-family: 'Nunito Sans', sans-serif;
  font-size: 0.95rem;
  height: 100px;
  overflow-y: hidden;
  margin-top: 15px;
`

export const Detail = styled.div`
  padding: 0 25px;
  display: flex;
  justify-content: space-between;
`

export const DatePublished = styled.p`
  text-align: left;
  font-family: 'Poppins', sans-serif;
  font-size: 0.8rem;
  color: var(--text-muted);
`

export const Author = styled.p`
  text-align: right;
  font-family: 'Poppins', sans-serif;
  font-size: 0.8rem;
  color: var(--text-muted);
`

export const Footer = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  gap: 10px;
`

export const InteractionContainer = styled.div`
  border-top: 1px solid var(--border);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 30px;
  height: 40px;
`

export const Interaction = styled.div`
  font-size: 0.7rem;
  display: flex;
  align-items: center;
  gap: 7px;

  & > * {
    display: block;
  }
`
