import OriginPostCard from './PostCard'
import Shimmer from './Shimmer'

const PostCard = OriginPostCard as typeof OriginPostCard & {
  Shimmer: typeof Shimmer
}

PostCard.Shimmer = Shimmer

export default PostCard
