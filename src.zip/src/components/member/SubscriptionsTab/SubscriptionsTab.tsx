import NoData from '../../../components/common/NoData'
import Spinner from '../../../components/common/Spinner'
import moment from 'moment'
import { useGetUserSubscriptionsQuery } from '../../../store/api/user'
import StatusCard from '../StatusCard'
import * as S from './SubscriptionsTab.style'

const SubscriptionsTab = () => {
  const {
    data: userSubscriptions,
    isLoading,
    error,
  } = useGetUserSubscriptionsQuery(undefined, {
    refetchOnMountOrArgChange: true,
  })

  const renderRewards = () => {
    if (isLoading) {
      return <Spinner />
    }

    if (!userSubscriptions || error) {
      return <p>Something went wrong</p>
    }

    if (userSubscriptions.length === 0) {
      return <NoData text='No subscription bought yet' />
    }

    return userSubscriptions.map((subscription) => (
      <StatusCard
        leftField='Valid Until:'
        leftValue={moment(subscription.date_ended).format('MMM Do, YYYY')}
        rightField='Remaining Quota:'
        rightValue={subscription.remaining_quota.toString()}
        key={subscription.id}
      />
    ))
  }

  return <S.Container>{renderRewards()}</S.Container>
}

export default SubscriptionsTab
