import useAppSelector from '../../../hooks/useAppSelector'
import { Navigate, Outlet } from 'react-router-dom'
import { useGetProfileQuery } from '../../../store/api/auth'
import LoadingOverlay from '../LoadingOverlay'

interface RequireAuthProps {
  redirectTo: string
  role: 'member' | 'admin'
}

const RequireAuth = ({ redirectTo, role }: RequireAuthProps) => {
  const { isAuthenticated } = useAppSelector((state) => state.auth)
  const { data: profile, isLoading } = useGetProfileQuery(undefined, {
    skip: !isAuthenticated,
    refetchOnMountOrArgChange: true,
  })

  return (
    <>
      {isLoading && <LoadingOverlay />}
      {!isLoading && (
        <>
          {!profile?.role || !isAuthenticated ? (
            <Navigate to='/login' />
          ) : (
            <>{profile?.role === role ? <Outlet /> : <Navigate to={redirectTo} />}</>
          )}
        </>
      )}
    </>
  )
}

export default RequireAuth
