import * as S from './Modal.style'
import { ReactComponent as CloseIcon } from '../../../assets/img/ic_close.svg'

interface ModalProps {
  isOpen: boolean
  toggle: () => void
  children: React.ReactNode
}

const Modal = ({ isOpen, toggle, children }: ModalProps) => {
  return isOpen ? (
    <S.Container>
      <S.Overlay onClick={toggle} />
      <S.ModalContainer>
        <S.CloseIconContainer onClick={toggle}>
          <CloseIcon />
        </S.CloseIconContainer>
        {children}
      </S.ModalContainer>
    </S.Container>
  ) : (
    <></>
  )
}

export default Modal
