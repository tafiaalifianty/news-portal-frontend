import styled from 'styled-components'

export const LabelUploadBtn = styled.label<{ showError: boolean }>`
  width: 100%;
  border-radius: 12px;
  padding: 16px 24px;
  border: 2px solid ${(props) => (props.showError ? 'var(--primary)' : 'var(--input-background-1)')};
  text-align: center;
  transition: 250ms ease-out;
  height: 150px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  &:hover {
    border: 2px solid var(--primary);
    cursor: pointer;
  }

  & > *:first-child {
    fill: #475467;
  }
`

export const UploadText = styled.p`
  font-weight: 500;
  font-family: 'Roboto';
  color: #475467;
  margin-top: 12px;
`

export const Input = styled.input`
  width: 0.1px;
  height: 0.1px;
  opacity: 0;
  overflow: hidden;
  position: absolute;
  z-index: -1;
`

export const Thumbnail = styled.img`
  height: 150px;
  object-fit: cover;
  width: 100%;
  border-radius: 12px;
`

export const ThumbnailExistLabel = styled.label`
  cursor: pointer;
`
