import { useEffect, useState } from 'react'
import * as S from './FileInput.style'
import { ReactComponent as UploadIcon } from '../../../assets/img/ic_upload.svg'

type FileInputProps = {
  showError?: any
  file: File
} & React.InputHTMLAttributes<HTMLInputElement>

const FileInput = ({ file, showError, ...props }: FileInputProps) => {
  const [thumbnail, setThumbnail] = useState<string>('')

  useEffect(() => {
    if (file) {
      setThumbnail(URL.createObjectURL(file))
    }
  }, [file])
  return (
    <>
      <S.Input
        autoComplete='off'
        id={props.name}
        {...props}
        type='file'
      />

      {thumbnail ? (
        <S.ThumbnailExistLabel htmlFor={props.name}>
          <S.Thumbnail src={thumbnail} />
        </S.ThumbnailExistLabel>
      ) : (
        <S.LabelUploadBtn
          showError={showError}
          htmlFor={props.name}
        >
          <UploadIcon
            width={40}
            height={40}
          />
          <S.UploadText>Click to Upload</S.UploadText>
        </S.LabelUploadBtn>
      )}
    </>
  )
}

export default FileInput
