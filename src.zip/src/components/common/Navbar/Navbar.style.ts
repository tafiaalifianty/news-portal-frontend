import { NavLink } from 'react-router-dom'
import styled from 'styled-components'
import { DefaultContainer } from '../../../styles/Page.style'
import { BaseShimmer } from '../../../styles/Shimer.style'
import Button from '../Button'

export const Container = styled.nav`
  height: 80px;
  border-bottom: 5px solid var(--primary);
  position: fixed;
  left: 0;
  right: 0;
  top: 0;
  background-color: var(--on-primary);
  z-index: 10;
`

export const InnerContainer = styled(DefaultContainer)`
  margin: auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 100%;
`

export const Logo = styled.img`
  width: 100px;

  &:hover {
    cursor: pointer;
  }
`

export const HomeLink = styled(NavLink)`
  text-decoration: none;
  transition: 250ms ease-out;
  font-size: 1.25rem;
  color: var(--text-muted);

  &:hover {
    color: var(--text);
    cursor: pointer;
  }
`

export const RightNavbarContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;

  & > *:last-child {
    &:hover {
      cursor: pointer;
    }
  }
`

export const AsideNavList = styled.div`
  position: absolute;
  right: -300px;
  top: 80px;
  border-left: 1px solid #ccc;
  height: calc(100vh - 80px);
  transition: ease-out 250ms;
  max-width: 300px;
  display: flex;
  flex-direction: column;
  padding: 10px 20px;
  gap: 10px;
  background-color: var(--on-primary);

  &.show {
    right: 0;
  }

  a,
  span {
    display: block;
    text-decoration: none;
    transition: 250ms ease-out;
    font-weight: 400;
    font-size: 1.25rem;
    padding: 10px 40px;
    border-radius: 20px;
    color: var(--text-muted);

    &:hover,
    &.active {
      color: var(--text);
      background-color: var(--primary-20);
      cursor: pointer;
    }
  }
`

export const SubscribeButton = styled(Button)`
  width: auto;
  padding: 10px;
  margin-right: 40px;
`

export const ProfileContainer = styled.div`
  display: flex;
  flex-direction: column;
  padding-left: 40px;
  padding-bottom: 10px;
  border-bottom: 1px solid var(--border);
`

export const UserName = styled.p`
  font-family: var(--normal-text);
  font-weight: 700;
  font-size: 1.3rem;
`

export const UserEmail = styled.p`
  font-family: var(--detail-text);
  font-size: 0.8rem;
`

export const UserNameShimmer = styled(BaseShimmer)`
  height: 1.3rem;
  margin-bottom: 10px;
`

export const UserEmailShimmer = styled(BaseShimmer)`
  height: 0.8rem;
  width: 50%;
`
