import Navbar, { ILink } from './Navbar'
import { Context as ResponsiveContext } from 'react-responsive'
import React from 'react'
import { BrowserRouterWrapper } from '../../../helpers/TestHelpers'
import { render, screen, waitFor } from '@testing-library/react'
import { Router } from 'react-router-dom'
import { createMemoryHistory } from 'history'
import userEvent from '@testing-library/user-event'
import { LOCAL_STORAGE_ACCESS_TOKEN_KEY } from '../../../constants/auth'

const mockLinks: ILink[] = [
  { path: '/', name: 'Home' },
  { path: '/subscriptions', name: 'Subscriptions' },
  { path: '/history', name: 'History' },
  { path: '/profile', name: 'Profile' },
]

const renderWithResponsiveContext = (children: React.ReactNode, width: number) =>
  render(<ResponsiveContext.Provider value={{ width }}>{children}</ResponsiveContext.Provider>)

describe('Navbar', () => {
  afterEach(() => {
    jest.clearAllMocks()
  })
  describe('Mobile', () => {
    test('should show mobile navbar on mobile screen', () => {
      renderWithResponsiveContext(
        <BrowserRouterWrapper>
          <Navbar links={mockLinks} />
        </BrowserRouterWrapper>,
        768
      )

      expect(screen.getByTestId('mobile-navbar')).toBeInTheDocument()
      expect(screen.queryByTestId('desktop-navbar')).not.toBeInTheDocument()
    })

    test.each`
      path                 | name
      ${mockLinks[0].path} | ${mockLinks[0].name}
      ${mockLinks[1].path} | ${mockLinks[1].name}
      ${mockLinks[2].path} | ${mockLinks[2].name}
      ${mockLinks[3].path} | ${mockLinks[3].name}
    `('should navigate to $path when $name link is clicked', async ({ path, name }) => {
      const history = createMemoryHistory()
      history.push('/random-route')
      renderWithResponsiveContext(
        <Router
          location={history.location}
          navigator={history}
        >
          <Navbar links={mockLinks} />
        </Router>,
        768
      )

      const link = screen.getByText(name)
      userEvent.click(link)
      await waitFor(() => {
        expect(history.location.pathname).toBe(path)
      })
    })

    test('should remove token local storage and navigate to login when logout is pressed', async () => {
      const localStorageSpy = jest.spyOn(Storage.prototype, 'removeItem')

      const history = createMemoryHistory()
      history.push('/random-route')
      renderWithResponsiveContext(
        <Router
          location={history.location}
          navigator={history}
        >
          <Navbar links={mockLinks} />
        </Router>,
        768
      )

      const logoutBtn = screen.getByText('Logout')
      userEvent.click(logoutBtn)
      await waitFor(() => {
        expect(localStorageSpy).toHaveBeenCalledWith(LOCAL_STORAGE_ACCESS_TOKEN_KEY)
        expect(history.location.pathname).toBe('/login')
      })
    })
  })

  describe('Desktop', () => {
    test('should show mobile navbar on mobile screen', () => {
      renderWithResponsiveContext(
        <BrowserRouterWrapper>
          <Navbar links={mockLinks} />
        </BrowserRouterWrapper>,
        769
      )

      expect(screen.getByTestId('desktop-navbar')).toBeInTheDocument()
      expect(screen.queryByTestId('mobile-navbar')).not.toBeInTheDocument()
    })

    test.each`
      path                 | name
      ${mockLinks[0].path} | ${mockLinks[0].name}
      ${mockLinks[1].path} | ${mockLinks[1].name}
      ${mockLinks[2].path} | ${mockLinks[2].name}
      ${mockLinks[3].path} | ${mockLinks[3].name}
    `('should navigate to $path when $name link is clicked', async ({ path, name }) => {
      const history = createMemoryHistory()
      history.push('/random-route')
      renderWithResponsiveContext(
        <Router
          location={history.location}
          navigator={history}
        >
          <Navbar links={mockLinks} />
        </Router>,
        769
      )

      const link = screen.getByText(name)
      userEvent.click(link)
      await waitFor(() => {
        expect(history.location.pathname).toBe(path)
      })
    })

    test('should remove token local storage and navigate to login when logout is pressed', async () => {
      const localStorageSpy = jest.spyOn(Storage.prototype, 'removeItem')

      const history = createMemoryHistory()
      history.push('/random-route')
      renderWithResponsiveContext(
        <Router
          location={history.location}
          navigator={history}
        >
          <Navbar links={mockLinks} />
        </Router>,
        769
      )

      const logoutBtn = screen.getByText('Logout')
      userEvent.click(logoutBtn)
      await waitFor(() => {
        expect(localStorageSpy).toHaveBeenCalledWith(LOCAL_STORAGE_ACCESS_TOKEN_KEY)
        expect(history.location.pathname).toBe('/login')
      })
    })
  })
})
