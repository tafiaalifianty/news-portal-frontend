import * as S from './Navbar.style'
import { ReactComponent as Logo } from '../../../assets/img/logo.svg'
import { ReactComponent as AsideIcon } from '../../../assets/img/aside.svg'
import { NavLink, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useAppDispatch } from '../../../hooks/useAppDispatch'
import { logout } from '../../../store/slice/authSlice'
import api from '../../../store/api'
import { useGetProfileQuery } from '../../../store/api/auth'

export interface ILink {
  path: string
  name: string
}

interface NavbarProps {
  links: ILink[]
  isEmpty?: boolean
}

const Navbar = ({ links, isEmpty = false }: NavbarProps) => {
  const [showAside, setShowAside] = useState<boolean>(false)
  const { data: profile, isLoading } = useGetProfileQuery()
  const navigate = useNavigate()
  const dispatch = useAppDispatch()

  const renderLinks = () => {
    return links.map((link) => (
      <NavLink
        onClick={() => setShowAside(false)}
        className={({ isActive }) => (isActive ? 'active' : '')}
        to={link.path}
        key={link.path}
        end
      >
        {link.name}
      </NavLink>
    ))
  }

  const onLogout = () => {
    dispatch(logout())
    dispatch(api.util.resetApiState())
  }

  return (
    <S.Container>
      <S.InnerContainer>
        <Logo
          style={{ height: '50px', cursor: 'pointer' }}
          onClick={() => navigate('/')}
        />
        {isEmpty ? (
          ''
        ) : (
          <>
            <S.RightNavbarContainer>
              <S.HomeLink
                onClick={() => setShowAside(false)}
                to='/'
                end
              >
                Home
              </S.HomeLink>
              {profile?.role === 'member' && (
                <S.SubscribeButton onClick={() => navigate('subscriptions')}>
                  Subscribe
                </S.SubscribeButton>
              )}
              <AsideIcon onClick={() => setShowAside(!showAside)} />
            </S.RightNavbarContainer>
            <S.AsideNavList
              className={showAside ? 'show' : ''}
              data-testid='mobile-navbar'
            >
              <S.ProfileContainer>
                {isLoading || !profile ? (
                  <>
                    <S.UserNameShimmer />
                    <S.UserEmailShimmer />
                  </>
                ) : (
                  <>
                    <S.UserName>{profile.fullname}</S.UserName>
                    <S.UserEmail>{profile.email}</S.UserEmail>
                  </>
                )}
              </S.ProfileContainer>
              {renderLinks()}
              <span onClick={onLogout}>Logout</span>
            </S.AsideNavList>
          </>
        )}
      </S.InnerContainer>
    </S.Container>
  )
}

export default Navbar
