import { useFormik } from 'formik'
import * as S from './Form.style'
import Button from '../Button'
import Input from '../Input'
import { HTMLInputTypeAttribute } from 'react'
import Dropdown from '../Dropdown'
import { DropdownOptions } from '../Dropdown/Dropdown'
import TextArea from '../TextArea'
import FileInput from '../FileInput'
import * as G from '../../../styles/Form.style'

export interface FormFieldConfig {
  name: string
  placeholder: string
  fieldType?: 'input' | 'dropdown' | 'textarea' | 'file'
  options?: DropdownOptions[]
  disabled?: boolean
  inputType?: HTMLInputTypeAttribute
  required?: boolean
}

interface FormProps {
  validationSchema: any
  onSubmit: (values: any) => any
  initialValues: any
  formFieldConfigs: FormFieldConfig[]
  btnText: string
  btnDisable?: boolean
}

const Form = ({
  initialValues,
  validationSchema,
  onSubmit,
  formFieldConfigs,
  btnText,
  btnDisable = false,
}: FormProps) => {
  const formik = useFormik({
    initialValues,
    validationSchema,
    validateOnBlur: false,
    validateOnChange: false,
    onSubmit,
  })

  const renderFields = () => {
    return formFieldConfigs.map((field) => {
      return (
        <G.Container key={field.name}>
          <G.Label htmlFor={field.name}>{field.placeholder}</G.Label>
          <G.InputContainer>
            {field.fieldType === 'dropdown' && (
              <Dropdown
                placeholder={field.placeholder}
                name={field.name}
                onChange={formik.handleChange}
                value={formik.values[field.name]}
                onBlur={formik.handleBlur}
                showError={formik.errors[field.name]}
                options={field.options ?? []}
                disabled={field.disabled}
              />
            )}
            {field.fieldType === 'textarea' && (
              <TextArea
                placeholder={field.placeholder}
                name={field.name}
                onChange={formik.handleChange}
                value={formik.values[field.name]}
                onBlur={formik.handleBlur}
                showError={formik.errors[field.name]}
                disabled={field.disabled}
                rows={8}
              />
            )}
            {field.fieldType === 'file' && (
              <FileInput
                id={field.name}
                name={field.name}
                file={formik.values[field.name]}
                type='file'
                placeholder={field.placeholder}
                showError={formik.errors[field.name]}
                onChange={async (e: React.ChangeEvent<HTMLInputElement>) => {
                  if (e.currentTarget.files) {
                    await formik.setFieldValue(field.name, e.currentTarget.files[0])
                  }
                }}
              />
            )}
            {(field.fieldType === 'input' || !field.fieldType) && (
              <Input
                placeholder={field.placeholder}
                name={field.name}
                onChange={formik.handleChange}
                value={formik.values[field.name]}
                onBlur={formik.handleBlur}
                showError={formik.errors[field.name]}
                disabled={field.disabled}
                type={field.inputType ?? 'text'}
              />
            )}
            {formik.errors[field.name] && <G.Error>{formik.errors[field.name] as any}</G.Error>}
          </G.InputContainer>
        </G.Container>
      )
    })
  }
  return (
    <S.Form onSubmit={formik.handleSubmit}>
      {renderFields()}

      <Button
        type='submit'
        disabled={btnDisable}
      >
        {btnText}
      </Button>
    </S.Form>
  )
}

export default Form
