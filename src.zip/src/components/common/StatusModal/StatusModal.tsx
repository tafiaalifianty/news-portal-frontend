import Modal from '../Modal'
import * as S from './StatusModal.style'
import { ReactComponent as IconSuccess } from '../../../assets/img/ic_success.svg'
import { ReactComponent as IconFailed } from '../../../assets/img/ic_failed.svg'

interface StatusModalProps {
  isLoading: boolean
  isOpen: boolean
  toggle: () => void
  title: string
  isError: boolean
}

const StatusModal = ({ isLoading, isOpen, isError, toggle, title }: StatusModalProps) => {
  return (
    <Modal
      isOpen={isOpen && !isLoading}
      toggle={toggle}
    >
      <S.InnerModalContainer>
        <S.ModalTitle>{title}</S.ModalTitle>
        {isError ? <IconFailed /> : <IconSuccess />}
      </S.InnerModalContainer>
    </Modal>
  )
}

export default StatusModal
