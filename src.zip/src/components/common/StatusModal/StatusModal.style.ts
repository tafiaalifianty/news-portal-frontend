import styled from 'styled-components'

export const Container = styled.div``

export const InnerModalContainer = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 40px;

  & > *:nth-child(2) {
    width: 150px;
    height: 150px;
  }
`

export const ModalTitle = styled.h1`
  font-family: 'IBM Plex Serif', sans-serif;
  text-align: center;
  margin-bottom: 40px;
  margin: 0;
`

export const ModalDescription = styled.p`
  font-family: 'Nunito Sans';
  font-weight: 500;
  font-size: 1.2rem;
`

export const RedirectText = styled.p`
  text-align: center;
  font-weight: 700;
  color: var(--primary);

  &:hover {
    cursor: pointer;
    color: var(--text);
  }
`
