import styled from 'styled-components'
import { formFieldStyles } from '../../../styles/Form.style'

export const Input = styled.input<{ showError: boolean }>`
  ${formFieldStyles}
  border: ${(props) => (props.showError ? '1px solid var(--primary)' : 'none')};
`
