import * as S from './Input.style'

type InputProps = {
  showError?: any
} & React.InputHTMLAttributes<HTMLInputElement>

const Input = ({ showError = false, ...props }: InputProps) => {
  return (
    <S.Input
      showError={showError}
      autoComplete='off'
      id={props.name}
      {...props}
    />
  )
}

export default Input
