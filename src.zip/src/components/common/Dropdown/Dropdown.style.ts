import styled from 'styled-components'
import { formFieldStyles } from '../../../styles/Form.style'

export const Select = styled.select<{ showError: boolean }>`
  ${formFieldStyles}
`

export const Option = styled.option``
