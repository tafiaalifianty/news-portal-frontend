/* eslint-disable react/prop-types */
import React from 'react'
import * as S from './Dropdown.style'

export interface DropdownOptions {
  value: any
  text: string
}

type DropdownProps = {
  options: DropdownOptions[]
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void
  showError?: any
  dropdownStyle?: React.CSSProperties
} & React.SelectHTMLAttributes<HTMLSelectElement>

const Dropdown = ({
  options,
  onChange,
  showError = false,
  dropdownStyle = {},
  ...props
}: DropdownProps) => {
  const renderOptions = () => {
    return options.map((option) => (
      <S.Option
        key={option.value}
        value={option.value}
      >
        {option.text}
      </S.Option>
    ))
  }
  return (
    <S.Select
      autoComplete='off'
      id={props.name}
      onChange={onChange}
      showError={showError}
      style={dropdownStyle}
      {...props}
    >
      {renderOptions()}
    </S.Select>
  )
}

export default Dropdown
