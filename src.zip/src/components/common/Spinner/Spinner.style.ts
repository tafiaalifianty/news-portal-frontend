import styled, { keyframes } from 'styled-components'

const spin = keyframes`
  from {
    transform: rotate(0deg);
  }

  to {
    transform: rotate(360deg);
  }
`

export const Spinner = styled.div<{ size: number }>`
  margin: auto;
  border: 16px solid var(--border);
  border-top: 16px solid var(--primary);
  border-radius: 50%;
  width: ${(props) => `${props.size}px`};
  height: ${(props) => `${props.size}px`};
  animation: ${spin} 2s linear infinite;
`
