import * as S from './Spinner.style'

interface SpinnerProps {
  size?: number
}

const Spinner = ({ size = 120 }: SpinnerProps) => {
  return <S.Spinner size={size} />
}

export default Spinner
