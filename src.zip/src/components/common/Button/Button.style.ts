import styled from 'styled-components'

export const Button = styled.button`
  font-weight: 700;
  outline: none;
  background-color: var(--primary);
  color: var(--on-primary);
  fill: var(--on-primary);
  border: 1px solid var(--on-primary);
  width: 100%;
  padding: 17px 0;
  border-radius: 20px;
  font-size: 1rem;
  transition: ease-in 200ms;

  &:hover {
    cursor: pointer;
    color: var(--primary);
    fill: var(--primary);
    background-color: var(--on-primary);
    border: 1px solid var(--primary);
  }

  &:disabled,
  &:disabled:hover {
    cursor: default;
    color: var(--on-primary);
    fill: var(--on-primary);
    border: 1px solid var(--border);
    background-color: var(--border);
  }
`
