import * as S from './TextArea.style'

type TextAreaProps = {
  showError?: any
} & React.TextareaHTMLAttributes<HTMLTextAreaElement>

const TextArea = ({ showError = false, ...props }: TextAreaProps) => {
  return (
    <S.TextArea
      showError={showError}
      autoComplete='off'
      id={props.name}
      {...props}
    />
  )
}

export default TextArea
