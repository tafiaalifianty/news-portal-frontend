import React, { useState } from 'react'
import * as S from './Tabs.style'

interface Tab {
  name: string
  content: React.ReactNode
}

interface TabsProps {
  tabs: Tab[]
}

const Tabs = ({ tabs }: TabsProps) => {
  const [activeTabIdx, setActiveTabIdx] = useState<number>(0)

  const onNavClick = (idx: number) => {
    setActiveTabIdx(idx)
  }

  return (
    <S.Container>
      <S.TabNavs>
        {tabs.map((tab, idx) => (
          <S.TabNavItem
            onClick={() => onNavClick(idx)}
            key={tab.name}
            className={activeTabIdx === idx ? 'active' : ''}
          >
            {tab.name}
          </S.TabNavItem>
        ))}
      </S.TabNavs>
      <S.TabContentContainer>
        {tabs.map((tab, idx) => (
          <div key={tab.name}>{activeTabIdx === idx && tab.content}</div>
        ))}
      </S.TabContentContainer>
    </S.Container>
  )
}

export default Tabs
