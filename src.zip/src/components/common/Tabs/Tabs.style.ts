import styled from 'styled-components'

export const Container = styled.div``

export const TabNavs = styled.ul`
  list-style-type: none;
  display: flex;
  border-bottom: 2px solid var(--border);
  padding: 10px;
  gap: 5px;
  margin-bottom: 20px;
`

export const TabNavItem = styled.li`
  padding: 5px 20px;
  font-family: var(--normal-text);
  border-radius: 5px;
  transition: 250ms ease-out;
  border-bottom: 2px solid transparent;

  &:hover {
    cursor: pointer;
    background-color: #EEEEEE;
  }

  &.active {
    border-bottom: 2px solid var(--primary);
    font-weight: 700;
  }
`

export const TabContentContainer = styled.div``
