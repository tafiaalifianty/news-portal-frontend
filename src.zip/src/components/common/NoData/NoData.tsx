import * as S from './NoData.style'
import { ReactComponent as NoDataIcon } from '../../../assets/img/ic_no_data.svg'

interface NoDataProps {
  text?: string
}

const NoData = ({ text = 'No Data Found' }: NoDataProps) => {
  return (
    <S.Container>
      <NoDataIcon style={{ height: 150, width: 150 }} />
      <S.Text>{text}</S.Text>
    </S.Container>
  )
}

export default NoData
