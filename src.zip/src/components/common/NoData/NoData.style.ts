import styled from 'styled-components'

export const Container = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
`

export const Text = styled.p`
  color: black;
  opacity: 0.54;
  font-size: 1.5rem;
  font-weight: 700;
  font-family: var(--detail-text);
`
