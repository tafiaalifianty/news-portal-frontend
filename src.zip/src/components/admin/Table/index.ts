export { default } from './Table'
