import * as S from './Table.style'

export interface TableHeader {
  name: string
  value: string
}

interface TableProps {
  headers: TableHeader[]
  data: any[]
}

export const Table = ({ headers, data }: TableProps) => {
  return (
    <S.Table cellSpacing={0}>
      <S.TableHead>
        <tr>
          {headers.map((header) => (
            <S.TableHeadColumn key={header.name}>{header.value}</S.TableHeadColumn>
          ))}
        </tr>
      </S.TableHead>
      <S.TableBody>
        {data.map((datum) => (
          <S.TableRow key={datum.id}>
            {headers.map((header) => (
              <S.TableColumn key={header.name}>{datum[header.name]}</S.TableColumn>
            ))}
          </S.TableRow>
        ))}
      </S.TableBody>
    </S.Table>
  )
}

export default Table
