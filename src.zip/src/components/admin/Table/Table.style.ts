import Button from '../../../components/common/Button'
import styled from 'styled-components'

export const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  overflow: auto;
`
export const TableHead = styled.thead`
  text-align: left;
  background-color: #edf2f7;
`

export const TableHeadColumn = styled.th`
  padding: 10px 20px;
  text-align: left;
  font-weight: 500;
  font-family: 'Roboto', sans-serif;
  color: #4a5568;
  font-size: 1rem;
`

export const TableBody = styled.tbody``

export const TableRow = styled.tr`
  border-bottom: 1px solid var(--border);
`

export const TableColumn = styled.td`
  padding: 15px 20px;
  font-size: 0.9rem;
  font-weight: 400;

  color: #2a2a2a;
  font-family: 'Roboto', sans-serif;

  & > * {
    margin: 0 auto;
  }
`

export const TableColumnAction = styled(TableColumn)`
  display: inline-flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: space-between;
  align-items: center;
  height: 100%;
`

export const ActionButton = styled(Button)`
  width: 40px;
  height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 10px;
`

export const DeleteButton = styled(ActionButton)``

export const UpdateButton = styled(ActionButton)`
  background-color: #109be9;
  &:hover {
    fill: #109be9;
    border: 1px solid #109be9;
  }
`
