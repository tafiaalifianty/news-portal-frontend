export const LOCAL_STORAGE_ACCESS_TOKEN_KEY = 'access_token'
export const LOCAL_STORAGE_REFRESH_TOKEN_KEY = 'refresh_token'
