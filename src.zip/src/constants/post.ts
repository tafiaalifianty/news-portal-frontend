export enum PostType {
  VIP = 'VIP',
  PREMIUM = 'Premium',
  FREE = 'Free',
}

export enum PostCategory {
  SPORT = 'Sport',
  FINANCE = 'Finance',
  TRAVEL = 'Travel',
  HEALTH = 'Health',
  FOOD = 'Food',
  TECHNOLOGY = 'Technology',
  AUTOMOTIVE = 'Automotive',
}
