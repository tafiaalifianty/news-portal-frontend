import styled, { keyframes } from 'styled-components'

const shimmerAnimation = keyframes`
  0% {
    background-position: 200% 0;
  }

  100% {
    background-position: 0 200%;
  }
`

export const BaseShimmer = styled.div`
  min-height: 16px;
  animation: ${shimmerAnimation} 4s linear infinite;
  background-image: linear-gradient(
    270deg,
    var(--shimmer-from) 25%,
    var(--shimmer-to) 35%,
    var(--shimmer-to) 65%,
    var(--shimmer-from) 75%
  );
  background-size: 400% 100%;
`
