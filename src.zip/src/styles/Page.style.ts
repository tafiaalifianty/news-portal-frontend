import styled from 'styled-components'

export const DefaultContainer = styled.div`
  max-width: 1440px;
  padding: 0 3%;
`

export const PageExternalContainer = styled.div`
  background-color: var(--dashboard-background);
`

export const DefaultPageContainer = styled(DefaultContainer)`
  padding: 50px 3%;
  min-height: calc(100vh - 80px);
  margin: 80px auto 0;
`
