import { createGlobalStyle } from 'styled-components'

export const GlobalStyle = createGlobalStyle`

  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Montserrat', sans-serif;
  }

  :root {
    --primary: #FFD369;
    --primary-20: rgba(255,211,105,0.2);

    --text: #000000;
    --text-muted: #AAAAAA;
    --on-primary: #FFFFFF;
    --border: #CCCCCC;

    --dashboard-background: #EEEEEE;

    --shimmer-from: #bbb;
    --shimmer-to: #999;

    --input-background-1: #FBFCF7;

    --title-text: 'Bebas Neue', sans-serif;
    --normal-text: 'Aurulent Sans', sans-serif;
    --detail-text: 'Open Sans', sans-serif;
  }
`
