import styled from 'styled-components'

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  gap: 11px;
  width: 100%;
`

export const Label = styled.label`
  font-weight: 500;
`

export const InputContainer = styled.div`
  width: 100%;
`

export const formFieldStyles = `
  background-color: var(--input-background-1);
  outline: none;
  border: none;
  border-radius: 20px;
  width: 100%;
  padding: 15px 22px;
  font-size: 1rem;

  &:disabled {
    background-color: #EEEEEE;
    color: #393E46;
  }
`

export const Select = styled.select<{ showError: boolean }>`
  ${formFieldStyles}
  border: ${(props) => (props.showError ? '1px solid var(--primary)' : 'none')};
`

export const Error = styled.span`
  display: block;
  color: #FFD369;
  font-size: 0.75rem;
  margin-top: 3px;
  padding-left: 10px;
`
