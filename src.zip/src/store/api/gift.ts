import moment from 'moment'
import Gift, { UserGift } from '../../types/Gift'
import api from './index'

interface UpdateGiftStock {
  id: number
  stock: number
}

interface UpdateRewardStatus {
  id: string
  isSuccess: boolean
}

export const giftApi = api.injectEndpoints({
  endpoints: (builder) => ({
    getAllGifts: builder.query<Gift[], void>({
      query: () => ({
        url: 'admin/gifts',
      }),
      transformResponse: (response: { data: Gift[] }) => {
        return response.data.map((datum) => {
          return {
            ...datum,
            updated_at: moment(datum.updated_at).format('MMMM Do YYYY'),
          }
        })
      },
      providesTags: ['gifts'],
    }),
    getAllUserRewards: builder.query<UserGift[], void>({
      query: () => ({
        url: 'admin/gifts/users',
      }),
      transformResponse: (response: { data: UserGift[] }) => {
        return response.data
      },
      providesTags: ['rewards'],
    }),
    updateGiftStock: builder.mutation<void, UpdateGiftStock>({
      query: ({ id, stock }) => ({
        url: `admin/gifts/stock/${id}`,
        method: 'PATCH',
        body: {
          stock,
        },
      }),
      invalidatesTags: ['gifts'],
    }),
    updateRewardStatus: builder.mutation<void, UpdateRewardStatus>({
      query: ({ id, isSuccess }) => ({
        url: `admin/gifts/users/${id}`,
        method: 'PATCH',
        body: {
          is_success: isSuccess,
        },
      }),
      invalidatesTags: ['rewards'],
    }),
  }),
})

export const {
  useGetAllGiftsQuery,
  useUpdateGiftStockMutation,
  useGetAllUserRewardsQuery,
  useUpdateRewardStatusMutation,
} = giftApi
