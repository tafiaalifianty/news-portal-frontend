import User from '../../types/User'
import api from './index'

export interface LoginRequest {
  email: string
  password: string
}
export interface LoginResponse {
  data: {
    id: number
    email: string
    access_token: string
    refresh_token: string
  }
}

export interface RegisterRequest {
  email: string
  fullName: string
  password: string
  address: string
  referral_code: string
}
export interface RegisterResponse {
  data: {
    id: number
    email: string
    access_token: string
    refresh_token: string
  }
}

export const authApi = api.injectEndpoints({
  endpoints: (builder) => ({
    login: builder.mutation<LoginResponse, LoginRequest>({
      query: (credentials) => ({
        url: 'login',
        method: 'POST',
        body: credentials,
      }),
    }),
    register: builder.mutation<RegisterResponse, RegisterRequest>({
      query: (credentials) => ({
        url: 'register',
        method: 'POST',
        body: credentials,
      }),
    }),
    getProfile: builder.query<User, void>({
      query: () => 'users/profile',
      transformResponse: (response: { data: User }) => {
        return response.data
      },
      providesTags: ['profile'],
    }),
  }),
})

export const { useLoginMutation, useGetProfileQuery, useLazyGetProfileQuery, useRegisterMutation } =
  authApi
