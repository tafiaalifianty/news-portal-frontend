import Voucher from '../../types/Voucher'
import api from './index'

export const voucherApi = api.injectEndpoints({
  endpoints: (builder) => ({
    getAllVouchers: builder.query<Voucher[], void>({
      query: () => ({
        url: 'admin/vouchers',
      }),
      transformResponse: (response: { data: Voucher[] }) => {
        return response.data
      },
      providesTags: ['vouchers'],
    }),
  }),
})

export const { useGetAllVouchersQuery } = voucherApi
