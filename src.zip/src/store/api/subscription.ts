import Subscription from '../../types/Subscription'
import api from './index'

export const subscriptionApi = api.injectEndpoints({
  endpoints: (builder) => ({
    getSubscriptions: builder.query<Subscription[], void>({
      query: () => 'subscriptions',
      transformResponse: (response: { data: Subscription[] }) => {
        return response.data
      },
    }),
  }),
})

export const { useGetSubscriptionsQuery } = subscriptionApi
