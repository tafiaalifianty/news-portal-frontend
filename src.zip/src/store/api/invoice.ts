import Invoice from '../../types/Invoice'
import api from './index'

export interface BuySubscriptionRequestBody {
  original_price: number
  subscription_id: number
  voucher_code: string
}

interface UpdateProcessedInvoiceRequestBody {
  code: string
  isSuccess: boolean
}

export const invoiceApi = api.injectEndpoints({
  endpoints: (builder) => ({
    buySubscription: builder.mutation<any, BuySubscriptionRequestBody>({
      query: (data) => ({
        url: 'invoices',
        method: 'POST',
        body: data,
      }),
    }),
    getInvoiceByCodeProtected: builder.query<Invoice, string>({
      query: (code) => `invoices/user/${code}`,
      transformResponse: (response: { data: Invoice }) => {
        return response.data
      },
    }),
    getInvoiceByCode: builder.query<Invoice, string>({
      query: (code) => `invoices/${code}`,
      transformResponse: (response: { data: Invoice }) => {
        return response.data
      },
    }),
    getUserInvoices: builder.query<Invoice[], void>({
      query: () => ({
        url: 'users/invoices',
      }),
      transformResponse: (response: { data: Invoice[] }) => {
        return response.data
      },
      providesTags: ['invoices'],
    }),
    getAllInvoice: builder.query<Invoice[], void>({
      query: () => ({
        url: 'admin/invoices',
      }),
      transformResponse: (response: { data: Invoice[] }) => {
        return response.data
      },
      providesTags: ['invoices'],
    }),
    updateWaitingInvoice: builder.mutation<void, string>({
      query: (code) => ({
        url: `invoices/${code}`,
        method: 'PATCH',
      }),
    }),
    updateProcessedInvoice: builder.mutation<void, UpdateProcessedInvoiceRequestBody>({
      query: ({ code, isSuccess }) => ({
        url: `admin/invoices/${code}`,
        method: 'PATCH',
        body: {
          is_success: isSuccess,
        },
      }),
      invalidatesTags: ['invoices'],
    }),
  }),
})

export const {
  useBuySubscriptionMutation,
  useGetInvoiceByCodeProtectedQuery,
  useGetInvoiceByCodeQuery,
  useUpdateWaitingInvoiceMutation,
  useGetAllInvoiceQuery,
  useGetUserInvoicesQuery,
  useUpdateProcessedInvoiceMutation,
} = invoiceApi
