import Post, { PostCategories, PostType } from '../../types/Post'
import ReadingHistory from '../../types/ReadingHistory'
import api from './index'

export interface AddPostRequest {
  title: string
  summary: string
  content: string
  type_id: string | number
  category_id: string | number
  img_url: string
  author_name: string
}

interface PaginatedResponse<T> {
  current_page: number
  per_page: number
  total: number
  total_pages: number
  data: T[]
}

interface GetAllPostQuery {
  page?: number
  limit?: number
  search?: string
  sort?: string
  category?: string
  type?: string
}

type GetPostByIDResponse = Post & Partial<ReadingHistory>

interface LikePostRequestBody {
  isLike: boolean
  id: number
}

export const postApi = api.injectEndpoints({
  endpoints: (builder) => ({
    getAllPost: builder.query<PaginatedResponse<Post>, GetAllPostQuery | void>({
      query: (
        { page, limit, search, sort, category, type } = {
          page: 1,
          limit: 10,
          search: '',
          sort: 'desc',
          category: '0',
          type: '0',
        }
      ) => ({
        url: 'posts',
        params: { limit, page, sort, category, type, s: search },
      }),
      transformResponse: (response: { data: PaginatedResponse<Post> }) => {
        return response.data
      },
      providesTags: ['posts'],
    }),
    getPostByID: builder.query<GetPostByIDResponse, number>({
      query: (id) => `posts/${id}`,
      providesTags: (_result, _err, id) => [{ type: 'posts', id }],
      transformResponse: (response: { data: GetPostByIDResponse }) => {
        return response.data
      },
    }),
    getRecommendationPosts: builder.query<Post[], void>({
      query: () => ({
        url: 'posts/recommendations',
      }),
      transformResponse: (response: { data: Post[] }) => {
        return response.data
      },
      providesTags: ['posts'],
    }),
    getTrendingPosts: builder.query<Post[], void>({
      query: () => ({
        url: 'posts/trending',
      }),
      transformResponse: (response: { data: Post[] }) => {
        return response.data
      },
      providesTags: ['posts'],
    }),
    getPostTypes: builder.query<PostType[], void>({
      query: () => 'posts/types',
      transformResponse: (response: { data: PostType[] }) => {
        return response.data
      },
    }),
    getPostCategories: builder.query<PostCategories[], void>({
      query: () => 'posts/categories',
      transformResponse: (response: { data: PostCategories[] }) => {
        return response.data
      },
    }),
    addPost: builder.mutation<void, AddPostRequest>({
      query: (data) => ({
        url: 'admin/posts',
        method: 'POST',
        body: data,
      }),
      invalidatesTags: ['posts'],
    }),
    likePost: builder.mutation<GetPostByIDResponse, LikePostRequestBody>({
      query: ({ isLike, id }) => ({
        url: `posts/like/${id}`,
        method: 'PATCH',
        body: {
          is_like: isLike,
        },
      }),
      invalidatesTags: (data) => [{ type: 'posts', id: data?.id }],
    }),
    sharePost: builder.mutation<GetPostByIDResponse, number>({
      query: (id) => ({
        url: `posts/share/${id}`,
        method: 'PATCH',
      }),
      invalidatesTags: (data) => [{ type: 'posts', id: data?.id }],
    }),
    deletePost: builder.mutation<void, number>({
      query: (id) => ({
        url: `admin/posts/${id}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['posts'],
    }),
  }),
})

export const {
  useGetAllPostQuery,
  useGetRecommendationPostsQuery,
  useGetTrendingPostsQuery,
  useGetPostByIDQuery,
  useGetPostTypesQuery,
  useGetPostCategoriesQuery,
  useAddPostMutation,
  useLikePostMutation,
  useSharePostMutation,
  useDeletePostMutation,
} = postApi
