import {
  BaseQueryFn,
  createApi,
  FetchArgs,
  fetchBaseQuery,
  FetchBaseQueryError,
} from '@reduxjs/toolkit/query/react'
import { LOCAL_STORAGE_ACCESS_TOKEN_KEY } from '../../constants/auth'
import { logout } from '../../store/slice/authSlice'

const baseQuery = fetchBaseQuery({
  baseUrl: process.env.REACT_APP_BASE_URL,
  prepareHeaders: (headers) => {
    const token = localStorage.getItem(LOCAL_STORAGE_ACCESS_TOKEN_KEY)
    if (token) {
      headers.set('authorization', `Bearer ${token}`)
    }
    return headers
  },
})

const baseQueryRefresh = fetchBaseQuery({
  baseUrl: process.env.REACT_APP_BASE_URL,
  prepareHeaders: (headers) => {
    const token = localStorage.getItem('refresh_token')
    if (token) {
      headers.set('authorization', `Bearer ${token}`)
    }
    return headers
  },
})

const baseQueryWithReauth: BaseQueryFn<string | FetchArgs, unknown, FetchBaseQueryError> = async (
  args,
  api,
  extraOptions
) => {
  let result = await baseQuery(args, api, extraOptions)
  if (result.error && result.error.status === 401) {
    const refreshResult = await baseQueryRefresh('/refresh', api, extraOptions)
    if (refreshResult.data) {
      localStorage.setItem(
        LOCAL_STORAGE_ACCESS_TOKEN_KEY,
        (refreshResult.data as { data: { access_token: string } }).data.access_token
      )
      result = await baseQuery(args, api, extraOptions)
    } else {
      api.dispatch(logout())
    }
  }
  return result
}

export default createApi({
  reducerPath: 'apiReducer',
  baseQuery: baseQueryWithReauth,
  tagTypes: ['posts', 'invoices', 'gifts', 'rewards', 'vouchers', 'profile', 'user_subscriptions'],
  endpoints: () => ({}),
})
