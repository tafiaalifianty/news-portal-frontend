import { UserGift } from '../../types/Gift'
import ReadingHistory from '../../types/ReadingHistory'
import User from '../../types/User'
import UserSpending from '../../types/UserSpending'
import UserSubscription from '../../types/UserSubscription'
import UserVoucher from '../../types/UserVoucher'
import api from './index'

type UpdateProfileRequest = Pick<User, 'fullname' | 'address'>

export const userApi = api.injectEndpoints({
  endpoints: (builder) => ({
    getUserHistories: builder.query<ReadingHistory[], void>({
      query: () => 'users/histories',
      transformResponse: (response: { data: ReadingHistory[] }) => {
        return response.data
      },
    }),
    getUserRewards: builder.query<UserGift[], void>({
      query: () => 'users/gifts',
      transformResponse: (response: { data: UserGift[] }) => {
        return response.data
      },
    }),
    getUserReferrals: builder.query<UserSpending[], void>({
      query: () => 'users/referrals',
      transformResponse: (response: { data: UserSpending[] }) => {
        return response.data
      },
    }),
    getUserVouchers: builder.query<UserVoucher[], void>({
      query: () => 'users/vouchers',
      transformResponse: (response: { data: UserVoucher[] }) => {
        return response.data
      },
    }),
    getUserSubscriptions: builder.query<UserSubscription[], void>({
      query: () => 'users/subscriptions',
      transformResponse: (response: { data: UserSubscription[] }) => {
        return response.data
      },
      providesTags: ['user_subscriptions'],
    }),
    updateUserProfile: builder.mutation<void, UpdateProfileRequest>({
      query: (data) => ({
        url: 'users/profile',
        method: 'PATCH',
        body: data,
      }),
      invalidatesTags: ['profile'],
    }),
  }),
})

export const {
  useGetUserHistoriesQuery,
  useGetUserRewardsQuery,
  useGetUserReferralsQuery,
  useGetUserVouchersQuery,
  useUpdateUserProfileMutation,
  useGetUserSubscriptionsQuery,
} = userApi
