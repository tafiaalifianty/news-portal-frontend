import { createSlice } from '@reduxjs/toolkit'
import { LOCAL_STORAGE_ACCESS_TOKEN_KEY, LOCAL_STORAGE_REFRESH_TOKEN_KEY } from '../../constants/auth'
import { authApi } from '../../store/api/auth'

interface AuthState {
  isAuthenticated: boolean
}

const initialState: AuthState = {
  isAuthenticated: localStorage.getItem(LOCAL_STORAGE_ACCESS_TOKEN_KEY) !== null,
}

const slice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    logout: (state) => {
      localStorage.removeItem(LOCAL_STORAGE_ACCESS_TOKEN_KEY)
      localStorage.removeItem(LOCAL_STORAGE_REFRESH_TOKEN_KEY)
      state.isAuthenticated = false
    },
  },
  extraReducers: (builder) => {
    builder.addMatcher(authApi.endpoints.login.matchFulfilled, (state, action) => {
      localStorage.setItem(LOCAL_STORAGE_ACCESS_TOKEN_KEY, action.payload.data.access_token)
      localStorage.setItem(LOCAL_STORAGE_REFRESH_TOKEN_KEY, action.payload.data.refresh_token)
      state.isAuthenticated = true
    })
    builder.addMatcher(authApi.endpoints.getProfile.matchRejected, (state, action) => {
      if (action.payload?.status === 'FETCH_ERROR') {
        localStorage.removeItem(LOCAL_STORAGE_ACCESS_TOKEN_KEY)
        localStorage.removeItem(LOCAL_STORAGE_REFRESH_TOKEN_KEY)
        state.isAuthenticated = false
      }
    })
    builder.addMatcher(authApi.endpoints.register.matchFulfilled, (state, action) => {
      localStorage.setItem(LOCAL_STORAGE_ACCESS_TOKEN_KEY, action.payload.data.access_token)
      localStorage.setItem(LOCAL_STORAGE_REFRESH_TOKEN_KEY, action.payload.data.refresh_token)
      state.isAuthenticated = true
    })
  },
})

export const { logout } = slice.actions
export default slice.reducer
