import Voucher from './Voucher'

interface UserVoucher {
  id: number
  code: string
  received_from_user_id: number
  received_from_user_email: string
  voucher_id: 3
  voucher: Voucher
  date_received: string
  valid_until: string
  is_valid: boolean
}

export default UserVoucher
