import Post from './Post'

interface ReadingHistory {
  last_accessed: string
  is_liked: boolean
  is_shared: boolean
  post: Post
}

export default ReadingHistory
