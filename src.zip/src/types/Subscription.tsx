interface Subscription {
  id: number
  name: string
  price: number
  quota: number
}

export default Subscription
