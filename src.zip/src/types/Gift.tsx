interface Gift {
  id: number
  name: string
  stock: number
  updated_at: string
}

export interface UserGift {
  user_id: number
  user_email: string
  gift_id: number
  gift_name: string
  month: number
  year: number
  status: 'PROCESSED' | 'COMPLETED' | 'CANCELLED'
}

export default Gift
