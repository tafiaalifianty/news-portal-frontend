interface Post {
  id: number
  title: string
  slug: string
  content: string
  summary: string
  category_id: number
  category: string
  type_id: number
  type: string
  img_url: string
  img_thumbnail: string
  author_name: string
  share_count: number
  like_count: number
  created_at: string
}

export interface PostType {
  id: number
  name: string
}

export interface PostCategories {
  id: number
  name: string
}

export default Post
