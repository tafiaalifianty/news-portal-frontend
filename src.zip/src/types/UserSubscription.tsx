interface UserSubscription {
  id: number
  subscription_id: number
  remaining_quota: number
  date_started: string
  date_ended: string
}

export default UserSubscription
