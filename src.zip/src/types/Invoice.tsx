import Subscription from './Subscription'

export type InvoiceStatus = 'WAITING' | 'PROCESSED' | 'COMPLETED' | 'REJECTED'

interface Invoice {
  id: number
  paid_at?: string
  status: InvoiceStatus
  subscription_id: string
  total: number
  user_id: number
  user_email?: string
  subscription?: Subscription
  subscription_plan?: string
  code: string
  purchased_at: string
}

export default Invoice
