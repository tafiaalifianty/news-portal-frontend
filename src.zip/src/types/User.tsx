interface User {
  id: number
  email: string
  role: 'member' | 'admin'
  fullname: string
  address: string
  referral_code?: string
}

export default User
