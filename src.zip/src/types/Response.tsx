export interface ResponseData {
  code: number
  message: string
  data: any
}

interface Response {
  data: ResponseData
}

export default Response
