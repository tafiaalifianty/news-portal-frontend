interface Voucher {
  id: number
  name: string
  discount: number
  minimum_spending: number
}

export default Voucher
