interface UserSpending {
  id: number
  email: string
  fullname: string
  total_spending: number
}

export default UserSpending
